"""
Financial Analysis Tool
Comprehensive financial analysis and reporting for PWD projects
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, date, timedelta
import numpy as np
import io

def main():
    """Main function for Financial Analysis tool"""
    st.markdown("### 📊 Financial Analysis")
    st.markdown("Comprehensive financial analysis and reporting for PWD projects and operations")
    
    # Analysis type selection
    analysis_type = st.selectbox(
        "Select Analysis Type:",
        [
            "Project Financial Analysis",
            "Budget vs Actual Analysis", 
            "Cost Trend Analysis",
            "Contractor Performance Analysis",
            "Department Financial Dashboard"
        ]
    )
    
    if analysis_type == "Project Financial Analysis":
        project_financial_analysis()
    elif analysis_type == "Budget vs Actual Analysis":
        budget_vs_actual_analysis()
    elif analysis_type == "Cost Trend Analysis":
        cost_trend_analysis()
    elif analysis_type == "Contractor Performance Analysis":
        contractor_performance_analysis()
    else:
        department_dashboard()

def project_financial_analysis():
    """Analyze financial performance of individual projects"""
    
    st.markdown("#### 💼 Project Financial Analysis")
    
    # Data input method
    input_method = st.radio(
        "Data Input Method:",
        ["Manual Entry", "Upload CSV Data"]
    )
    
    if input_method == "Manual Entry":
        manual_project_analysis()
    else:
        upload_project_data()

def manual_project_analysis():
    """Manual project financial analysis"""
    
    with st.form("project_analysis_form"):
        # Project basic information
        col1, col2 = st.columns(2)
        
        with col1:
            project_name = st.text_input("Project Name*", placeholder="Enter project name")
            project_code = st.text_input("Project Code", placeholder="Project ID")
            project_type = st.selectbox("Project Type", [
                "Road Construction", "Building Construction", "Bridge Construction",
                "Water Supply", "Irrigation", "Maintenance", "Other"
            ])
            start_date = st.date_input("Project Start Date*")
        
        with col2:
            contractor_name = st.text_input("Contractor Name", placeholder="Contractor name")
            agreement_amount = st.number_input("Agreement Amount (₹)*", min_value=0.0, format="%.2f")
            expected_completion = st.date_input("Expected Completion*")
            current_status = st.selectbox("Current Status", [
                "In Progress", "Completed", "Delayed", "On Hold", "Cancelled"
            ])
        
        # Financial data
        st.markdown("#### Financial Data")
        col3, col4, col5 = st.columns(3)
        
        with col3:
            work_done_amount = st.number_input("Work Done Amount (₹)*", min_value=0.0, format="%.2f")
            payments_made = st.number_input("Payments Made (₹)*", min_value=0.0, format="%.2f")
        
        with col4:
            mobilization_advance = st.number_input("Mobilization Advance (₹)", min_value=0.0, format="%.2f")
            material_advance = st.number_input("Material Advance (₹)", min_value=0.0, format="%.2f")
        
        with col5:
            security_deposit = st.number_input("Security Deposit (₹)", min_value=0.0, format="%.2f")
            retention_amount = st.number_input("Retention Amount (₹)", min_value=0.0, format="%.2f")
        
        # Additional costs
        st.markdown("#### Additional Costs & Deductions")
        col6, col7 = st.columns(2)
        
        with col6:
            extra_items_cost = st.number_input("Extra Items Cost (₹)", min_value=0.0, format="%.2f")
            escalation_cost = st.number_input("Price Escalation (₹)", min_value=0.0, format="%.2f")
        
        with col7:
            penalty_amount = st.number_input("Penalty Deducted (₹)", min_value=0.0, format="%.2f")
            other_deductions = st.number_input("Other Deductions (₹)", min_value=0.0, format="%.2f")
        
        submitted = st.form_submit_button("Analyze Project Finances", use_container_width=True)
    
    if submitted:
        if not all([project_name, agreement_amount > 0, work_done_amount >= 0, payments_made >= 0]):
            st.error("Please fill all required fields marked with *")
            return
        
        # Perform analysis
        analyze_project_finances(
            project_name, project_code, project_type, contractor_name,
            agreement_amount, work_done_amount, payments_made, mobilization_advance,
            material_advance, security_deposit, retention_amount, extra_items_cost,
            escalation_cost, penalty_amount, other_deductions, start_date,
            expected_completion, current_status
        )

def analyze_project_finances(project_name, project_code, project_type, contractor_name,
                           agreement_amount, work_done_amount, payments_made, mobilization_advance,
                           material_advance, security_deposit, retention_amount, extra_items_cost,
                           escalation_cost, penalty_amount, other_deductions, start_date,
                           expected_completion, current_status):
    """Perform comprehensive project financial analysis"""
    
    # Calculate key metrics
    physical_progress = (work_done_amount / agreement_amount * 100) if agreement_amount > 0 else 0
    financial_progress = (payments_made / agreement_amount * 100) if agreement_amount > 0 else 0
    
    outstanding_amount = work_done_amount - payments_made
    total_advances = mobilization_advance + material_advance
    total_deductions = penalty_amount + other_deductions + retention_amount
    
    revised_contract_value = agreement_amount + extra_items_cost + escalation_cost
    cost_escalation_percent = ((revised_contract_value - agreement_amount) / agreement_amount * 100) if agreement_amount > 0 else 0
    
    # Project duration analysis
    project_duration = (expected_completion - start_date).days
    days_elapsed = (date.today() - start_date).days
    time_progress = (days_elapsed / project_duration * 100) if project_duration > 0 else 0
    
    st.success("✅ Financial analysis completed!")
    
    # Display key metrics
    st.markdown("---")
    st.markdown("## 📊 PROJECT FINANCIAL ANALYSIS")
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Physical Progress", f"{physical_progress:.1f}%", 
                 delta=f"₹{work_done_amount:,.0f}")
    
    with col2:
        st.metric("Financial Progress", f"{financial_progress:.1f}%",
                 delta=f"₹{payments_made:,.0f}")
    
    with col3:
        st.metric("Outstanding Amount", f"₹{outstanding_amount:,.0f}")
    
    with col4:
        st.metric("Cost Escalation", f"{cost_escalation_percent:+.1f}%",
                 delta=f"₹{revised_contract_value - agreement_amount:,.0f}")
    
    # Project information
    st.markdown("### Project Information")
    
    info_col1, info_col2 = st.columns(2)
    
    with info_col1:
        st.markdown(f"""
        **Project Name:** {project_name}  
        **Project Code:** {project_code}  
        **Project Type:** {project_type}  
        **Contractor:** {contractor_name}  
        **Status:** {current_status}
        """)
    
    with info_col2:
        st.markdown(f"""
        **Start Date:** {start_date.strftime('%d/%m/%Y')}  
        **Expected Completion:** {expected_completion.strftime('%d/%m/%Y')}  
        **Project Duration:** {project_duration} days  
        **Time Elapsed:** {days_elapsed} days  
        **Time Progress:** {time_progress:.1f}%
        """)
    
    # Financial breakdown
    create_financial_breakdown_chart(agreement_amount, work_done_amount, payments_made, outstanding_amount)
    
    # Progress comparison
    create_progress_comparison_chart(physical_progress, financial_progress, time_progress)
    
    # Detailed financial table
    display_detailed_financial_table(
        agreement_amount, work_done_amount, payments_made, total_advances,
        security_deposit, retention_amount, extra_items_cost, escalation_cost,
        penalty_amount, other_deductions, revised_contract_value
    )
    
    # Cash flow analysis
    analyze_cash_flow(payments_made, outstanding_amount, total_advances, retention_amount)
    
    # Risk assessment
    assess_financial_risks(physical_progress, financial_progress, time_progress, cost_escalation_percent)
    
    # Generate downloadable report
    generate_project_analysis_report(project_name, physical_progress, financial_progress, outstanding_amount)

def create_financial_breakdown_chart(agreement_amount, work_done_amount, payments_made, outstanding_amount):
    """Create financial breakdown visualization"""
    
    st.markdown("### 💰 Financial Breakdown")
    
    # Pie chart for financial distribution
    financial_data = {
        'Category': ['Payments Made', 'Outstanding Amount', 'Remaining Work'],
        'Amount': [
            payments_made,
            outstanding_amount,
            max(0, agreement_amount - work_done_amount)
        ]
    }
    
    fig_pie = px.pie(
        financial_data,
        values='Amount',
        names='Category',
        title='Financial Distribution',
        color_discrete_sequence=['#1A8A16', '#FF6B35', '#6C757D']
    )
    
    fig_pie.update_layout(height=400)
    st.plotly_chart(fig_pie, use_container_width=True)

def create_progress_comparison_chart(physical_progress, financial_progress, time_progress):
    """Create progress comparison chart"""
    
    st.markdown("### 📈 Progress Comparison")
    
    progress_data = {
        'Progress Type': ['Physical Progress', 'Financial Progress', 'Time Progress'],
        'Percentage': [physical_progress, financial_progress, time_progress]
    }
    
    fig_bar = px.bar(
        progress_data,
        x='Progress Type',
        y='Percentage',
        title='Progress Comparison',
        color='Progress Type',
        color_discrete_sequence=['#FF6B35', '#004E89', '#1A8A16']
    )
    
    fig_bar.update_layout(height=400, showlegend=False, yaxis_range=[0, 100])
    fig_bar.add_hline(y=100, line_dash="dash", line_color="red", annotation_text="Target: 100%")
    
    st.plotly_chart(fig_bar, use_container_width=True)

def display_detailed_financial_table(agreement_amount, work_done_amount, payments_made, total_advances,
                                    security_deposit, retention_amount, extra_items_cost, escalation_cost,
                                    penalty_amount, other_deductions, revised_contract_value):
    """Display detailed financial breakdown table"""
    
    st.markdown("### 📋 Detailed Financial Breakdown")
    
    financial_details = {
        'Component': [
            'Original Agreement Amount',
            'Extra Items Cost',
            'Price Escalation',
            'Revised Contract Value',
            'Work Done Amount',
            'Payments Made',
            'Outstanding Amount',
            'Mobilization & Material Advance',
            'Security Deposit Held',
            'Retention Amount',
            'Penalty Deducted',
            'Other Deductions',
            'Net Amount Due'
        ],
        'Amount (₹)': [
            f"{agreement_amount:,.2f}",
            f"{extra_items_cost:,.2f}",
            f"{escalation_cost:,.2f}",
            f"{revised_contract_value:,.2f}",
            f"{work_done_amount:,.2f}",
            f"{payments_made:,.2f}",
            f"{work_done_amount - payments_made:,.2f}",
            f"{total_advances:,.2f}",
            f"{security_deposit:,.2f}",
            f"{retention_amount:,.2f}",
            f"{penalty_amount:,.2f}",
            f"{other_deductions:,.2f}",
            f"{work_done_amount - payments_made - retention_amount:,.2f}"
        ]
    }
    
    financial_df = pd.DataFrame(financial_details)
    st.table(financial_df)

def analyze_cash_flow(payments_made, outstanding_amount, total_advances, retention_amount):
    """Analyze project cash flow"""
    
    st.markdown("### 💸 Cash Flow Analysis")
    
    # Cash flow components
    cash_inflow = payments_made + total_advances
    cash_outflow = payments_made
    net_cash_flow = outstanding_amount - retention_amount
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Cash Inflow", f"₹{cash_inflow:,.0f}", "Payments + Advances")
    
    with col2:
        st.metric("Cash Outflow", f"₹{cash_outflow:,.0f}", "Actual Payments")
    
    with col3:
        st.metric("Net Cash Flow", f"₹{net_cash_flow:,.0f}", "Outstanding - Retention")
    
    # Cash flow status
    if net_cash_flow > 0:
        st.success("✅ Positive cash flow - Amount due to contractor")
    elif net_cash_flow < 0:
        st.warning("⚠️ Negative cash flow - Contractor owes to department")
    else:
        st.info("ℹ️ Balanced cash flow")

def assess_financial_risks(physical_progress, financial_progress, time_progress, cost_escalation_percent):
    """Assess financial risks in the project"""
    
    st.markdown("### ⚠️ Financial Risk Assessment")
    
    risks = []
    risk_level = "Low"
    
    # Progress mismatch risk
    progress_diff = abs(physical_progress - financial_progress)
    if progress_diff > 10:
        risks.append(f"Progress Mismatch: {progress_diff:.1f}% difference between physical and financial progress")
        risk_level = "Medium"
    
    # Time vs progress risk
    if time_progress > physical_progress + 15:
        risks.append("Schedule Risk: Project is behind schedule relative to time elapsed")
        risk_level = "High"
    
    # Cost escalation risk
    if cost_escalation_percent > 15:
        risks.append(f"Cost Escalation Risk: {cost_escalation_percent:.1f}% increase from original contract")
        risk_level = "High"
    elif cost_escalation_percent > 5:
        risks.append(f"Moderate Cost Escalation: {cost_escalation_percent:.1f}% increase from original contract")
        if risk_level == "Low":
            risk_level = "Medium"
    
    # Performance risk
    if physical_progress < 50 and time_progress > 75:
        risks.append("Performance Risk: Low physical progress despite significant time elapsed")
        risk_level = "High"
    
    # Display risk assessment
    if risk_level == "Low":
        st.success(f"🟢 **Risk Level: {risk_level}** - Project financials are healthy")
    elif risk_level == "Medium":
        st.warning(f"🟡 **Risk Level: {risk_level}** - Monitor closely for potential issues")
    else:
        st.error(f"🔴 **Risk Level: {risk_level}** - Immediate attention required")
    
    if risks:
        st.markdown("**Identified Risks:**")
        for risk in risks:
            st.write(f"• {risk}")
    else:
        st.write("No significant financial risks identified.")

def budget_vs_actual_analysis():
    """Analyze budget vs actual expenditure"""
    
    st.markdown("#### 📊 Budget vs Actual Analysis")
    
    # Initialize session state for budget data
    if 'budget_data' not in st.session_state:
        st.session_state.budget_data = []
    
    # Budget entry form
    with st.expander("➕ Add Budget vs Actual Data", expanded=True):
        with st.form("budget_entry_form"):
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                category = st.text_input("Category/Item", placeholder="e.g., Materials, Labor")
                budget_amount = st.number_input("Budget Amount (₹)", min_value=0.0, format="%.2f")
            
            with col2:
                actual_amount = st.number_input("Actual Amount (₹)", min_value=0.0, format="%.2f")
                period = st.selectbox("Period", ["Q1", "Q2", "Q3", "Q4", "Annual"])
            
            with col3:
                department = st.text_input("Department/Division", placeholder="PWD Division")
                year = st.number_input("Year", min_value=2020, max_value=2030, value=2024)
            
            with col4:
                remarks = st.text_area("Remarks", height=80)
            
            if st.form_submit_button("Add Entry"):
                if category and budget_amount > 0:
                    variance = actual_amount - budget_amount
                    variance_percent = (variance / budget_amount * 100) if budget_amount > 0 else 0
                    
                    new_entry = {
                        'Category': category,
                        'Budget Amount': budget_amount,
                        'Actual Amount': actual_amount,
                        'Variance': variance,
                        'Variance %': variance_percent,
                        'Period': period,
                        'Year': year,
                        'Department': department,
                        'Remarks': remarks
                    }
                    
                    st.session_state.budget_data.append(new_entry)
                    st.success("Entry added successfully!")
                    st.rerun()
    
    # Display budget analysis
    if st.session_state.budget_data:
        analyze_budget_data()
    else:
        st.info("Add budget vs actual data to start analysis")

def analyze_budget_data():
    """Analyze budget vs actual data"""
    
    df = pd.DataFrame(st.session_state.budget_data)
    
    st.markdown("### 📊 Budget vs Actual Analysis Results")
    
    # Summary metrics
    total_budget = df['Budget Amount'].sum()
    total_actual = df['Actual Amount'].sum()
    total_variance = df['Variance'].sum()
    overall_variance_percent = (total_variance / total_budget * 100) if total_budget > 0 else 0
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Budget", f"₹{total_budget:,.0f}")
    
    with col2:
        st.metric("Total Actual", f"₹{total_actual:,.0f}")
    
    with col3:
        st.metric("Total Variance", f"₹{total_variance:,.0f}", 
                 delta=f"{overall_variance_percent:+.1f}%")
    
    with col4:
        utilization_rate = (total_actual / total_budget * 100) if total_budget > 0 else 0
        st.metric("Budget Utilization", f"{utilization_rate:.1f}%")
    
    # Detailed table
    st.markdown("### 📋 Detailed Budget Analysis")
    
    # Format data for display
    display_df = df.copy()
    display_df['Budget Amount'] = display_df['Budget Amount'].apply(lambda x: f"₹{x:,.2f}")
    display_df['Actual Amount'] = display_df['Actual Amount'].apply(lambda x: f"₹{x:,.2f}")
    display_df['Variance'] = display_df['Variance'].apply(lambda x: f"₹{x:,.2f}")
    display_df['Variance %'] = display_df['Variance %'].apply(lambda x: f"{x:+.1f}%")
    
    st.dataframe(display_df, use_container_width=True)
    
    # Variance analysis chart
    create_variance_chart(df)
    
    # Category-wise analysis
    analyze_by_category(df)

def create_variance_chart(df):
    """Create variance analysis chart"""
    
    st.markdown("### 📈 Variance Analysis")
    
    # Bar chart comparing budget vs actual
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        name='Budget',
        x=df['Category'],
        y=df['Budget Amount'],
        marker_color='#004E89'
    ))
    
    fig.add_trace(go.Bar(
        name='Actual',
        x=df['Category'],
        y=df['Actual Amount'],
        marker_color='#FF6B35'
    ))
    
    fig.update_layout(
        title='Budget vs Actual Comparison',
        xaxis_title='Category',
        yaxis_title='Amount (₹)',
        barmode='group',
        height=400
    )
    
    st.plotly_chart(fig, use_container_width=True)

def analyze_by_category(df):
    """Analyze budget variance by category"""
    
    st.markdown("### 🏷️ Category-wise Analysis")
    
    category_summary = df.groupby('Category').agg({
        'Budget Amount': 'sum',
        'Actual Amount': 'sum',
        'Variance': 'sum'
    }).reset_index()
    
    category_summary['Variance %'] = (category_summary['Variance'] / category_summary['Budget Amount'] * 100)
    
    # Format for display
    category_display = category_summary.copy()
    category_display['Budget Amount'] = category_display['Budget Amount'].apply(lambda x: f"₹{x:,.0f}")
    category_display['Actual Amount'] = category_display['Actual Amount'].apply(lambda x: f"₹{x:,.0f}")
    category_display['Variance'] = category_display['Variance'].apply(lambda x: f"₹{x:,.0f}")
    category_display['Variance %'] = category_display['Variance %'].apply(lambda x: f"{x:+.1f}%")
    
    st.table(category_display)

def cost_trend_analysis():
    """Analyze cost trends over time"""
    
    st.markdown("#### 📈 Cost Trend Analysis")
    
    st.info("Upload historical cost data or enter manually to analyze trends")
    
    # Sample data for demonstration
    if st.button("Load Sample Cost Data"):
        create_sample_cost_data()

def create_sample_cost_data():
    """Create sample cost trend data"""
    
    # Generate sample data
    dates = pd.date_range(start='2023-01-01', end='2024-09-01', freq='M')
    
    # Sample cost categories
    categories = ['Materials', 'Labor', 'Equipment', 'Overhead']
    
    sample_data = []
    for date in dates:
        for category in categories:
            # Simulate cost trends with some randomness
            base_cost = {'Materials': 100000, 'Labor': 80000, 'Equipment': 60000, 'Overhead': 40000}
            trend_factor = 1 + (date.year - 2023) * 0.05  # 5% annual increase
            seasonal_factor = 1 + 0.1 * np.sin(2 * np.pi * date.month / 12)  # Seasonal variation
            random_factor = 1 + np.random.normal(0, 0.1)  # Random variation
            
            cost = base_cost[category] * trend_factor * seasonal_factor * random_factor
            
            sample_data.append({
                'Date': date,
                'Category': category,
                'Cost': cost,
                'Month': date.strftime('%Y-%m')
            })
    
    df = pd.DataFrame(sample_data)
    
    # Display trend analysis
    st.markdown("### 📈 Cost Trend Analysis (Sample Data)")
    
    # Line chart for cost trends
    fig = px.line(
        df,
        x='Date',
        y='Cost',
        color='Category',
        title='Cost Trends Over Time',
        color_discrete_sequence=['#FF6B35', '#004E89', '#1A8A16', '#6C757D']
    )
    
    fig.update_layout(height=400)
    st.plotly_chart(fig, use_container_width=True)
    
    # Monthly analysis
    monthly_summary = df.groupby(['Month', 'Category'])['Cost'].sum().reset_index()
    pivot_data = monthly_summary.pivot(index='Month', columns='Category', values='Cost')
    
    st.markdown("### 📊 Monthly Cost Summary")
    st.dataframe(pivot_data.style.format("₹{:,.0f}"), use_container_width=True)

def contractor_performance_analysis():
    """Analyze contractor financial performance"""
    
    st.markdown("#### 👥 Contractor Performance Analysis")
    
    st.info("This feature analyzes contractor performance based on financial metrics")
    
    # Placeholder for contractor analysis
    if st.button("Generate Sample Contractor Analysis"):
        create_sample_contractor_analysis()

def create_sample_contractor_analysis():
    """Create sample contractor performance analysis"""
    
    # Sample contractor data
    contractors = [
        {
            'Name': 'ABC Construction',
            'Projects': 5,
            'Total Value': 50000000,
            'Completed Value': 45000000,
            'Payment Efficiency': 92,
            'Quality Score': 85,
            'Time Performance': 88
        },
        {
            'Name': 'XYZ Builders',
            'Projects': 3,
            'Total Value': 30000000,
            'Completed Value': 28000000,
            'Payment Efficiency': 95,
            'Quality Score': 90,
            'Time Performance': 85
        },
        {
            'Name': 'PQR Infrastructure',
            'Projects': 8,
            'Total Value': 80000000,
            'Completed Value': 70000000,
            'Payment Efficiency': 88,
            'Quality Score': 82,
            'Time Performance': 90
        }
    ]
    
    df = pd.DataFrame(contractors)
    
    st.markdown("### 👥 Contractor Performance Dashboard")
    
    # Performance metrics
    col1, col2, col3 = st.columns(3)
    
    with col1:
        avg_payment_efficiency = df['Payment Efficiency'].mean()
        st.metric("Avg Payment Efficiency", f"{avg_payment_efficiency:.1f}%")
    
    with col2:
        avg_quality = df['Quality Score'].mean()
        st.metric("Avg Quality Score", f"{avg_quality:.1f}/100")
    
    with col3:
        avg_time_performance = df['Time Performance'].mean()
        st.metric("Avg Time Performance", f"{avg_time_performance:.1f}%")
    
    # Contractor comparison
    st.markdown("### 📊 Contractor Comparison")
    
    # Format display data
    display_df = df.copy()
    display_df['Total Value'] = display_df['Total Value'].apply(lambda x: f"₹{x:,.0f}")
    display_df['Completed Value'] = display_df['Completed Value'].apply(lambda x: f"₹{x:,.0f}")
    display_df['Payment Efficiency'] = display_df['Payment Efficiency'].apply(lambda x: f"{x}%")
    display_df['Time Performance'] = display_df['Time Performance'].apply(lambda x: f"{x}%")
    
    st.dataframe(display_df, use_container_width=True)
    
    # Performance radar chart
    create_contractor_radar_chart(df)

def create_contractor_radar_chart(df):
    """Create radar chart for contractor performance"""
    
    st.markdown("### 🎯 Performance Radar Chart")
    
    fig = go.Figure()
    
    for _, contractor in df.iterrows():
        fig.add_trace(go.Scatterpolar(
            r=[contractor['Payment Efficiency'], contractor['Quality Score'], contractor['Time Performance']],
            theta=['Payment Efficiency', 'Quality Score', 'Time Performance'],
            fill='toself',
            name=contractor['Name']
        ))
    
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 100]
            )),
        showlegend=True,
        title="Contractor Performance Comparison",
        height=500
    )
    
    st.plotly_chart(fig, use_container_width=True)

def department_dashboard():
    """Create department financial dashboard"""
    
    st.markdown("#### 🏢 Department Financial Dashboard")
    
    st.info("Comprehensive financial overview of PWD operations")
    
    # Generate sample dashboard
    create_department_dashboard()

def create_department_dashboard():
    """Create comprehensive department dashboard"""
    
    st.markdown("### 🏢 PWD Financial Dashboard")
    
    # Key performance indicators
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Projects", "45", delta="5 new")
    
    with col2:
        st.metric("Total Budget", "₹500 Cr", delta="₹50 Cr increased")
    
    with col3:
        st.metric("Budget Utilization", "78%", delta="5% from last month")
    
    with col4:
        st.metric("Active Contracts", "32", delta="-3 completed")
    
    # Budget allocation chart
    create_budget_allocation_chart()
    
    # Project status distribution
    create_project_status_chart()
    
    # Monthly expenditure trend
    create_expenditure_trend_chart()

def create_budget_allocation_chart():
    """Create budget allocation visualization"""
    
    st.markdown("### 💰 Budget Allocation by Category")
    
    budget_data = {
        'Category': ['Road Construction', 'Building Works', 'Bridge Construction', 'Maintenance', 'Water Supply'],
        'Allocation': [150, 120, 80, 75, 65],
        'Utilized': [120, 95, 65, 70, 55]
    }
    
    df = pd.DataFrame(budget_data)
    
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        name='Allocated',
        x=df['Category'],
        y=df['Allocation'],
        marker_color='#004E89'
    ))
    
    fig.add_trace(go.Bar(
        name='Utilized',
        x=df['Category'],
        y=df['Utilized'],
        marker_color='#FF6B35'
    ))
    
    fig.update_layout(
        title='Budget Allocation vs Utilization (₹ Crores)',
        xaxis_title='Category',
        yaxis_title='Amount (₹ Crores)',
        barmode='group',
        height=400
    )
    
    st.plotly_chart(fig, use_container_width=True)

def create_project_status_chart():
    """Create project status distribution chart"""
    
    st.markdown("### 📊 Project Status Distribution")
    
    status_data = {
        'Status': ['In Progress', 'Completed', 'Delayed', 'On Hold'],
        'Count': [25, 15, 8, 2]
    }
    
    fig = px.pie(
        status_data,
        values='Count',
        names='Status',
        title='Project Status Distribution',
        color_discrete_sequence=['#1A8A16', '#004E89', '#FF6B35', '#6C757D']
    )
    
    fig.update_layout(height=400)
    st.plotly_chart(fig, use_container_width=True)

def create_expenditure_trend_chart():
    """Create monthly expenditure trend chart"""
    
    st.markdown("### 📈 Monthly Expenditure Trend")
    
    # Generate sample monthly data
    months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep']
    expenditure = [45, 52, 48, 55, 62, 58, 65, 70, 68]
    budget = [50, 50, 50, 60, 60, 60, 70, 70, 70]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=months,
        y=budget,
        mode='lines+markers',
        name='Budget',
        line=dict(color='#004E89', width=3)
    ))
    
    fig.add_trace(go.Scatter(
        x=months,
        y=expenditure,
        mode='lines+markers',
        name='Actual Expenditure',
        line=dict(color='#FF6B35', width=3)
    ))
    
    fig.update_layout(
        title='Monthly Budget vs Expenditure Trend (₹ Crores)',
        xaxis_title='Month',
        yaxis_title='Amount (₹ Crores)',
        height=400
    )
    
    st.plotly_chart(fig, use_container_width=True)

def upload_project_data():
    """Upload and analyze project data from CSV"""
    
    st.markdown("#### 📂 Upload Project Data")
    
    uploaded_file = st.file_uploader(
        "Choose CSV file with project financial data",
        type=['csv'],
        help="Upload CSV file containing project financial information"
    )
    
    if uploaded_file is not None:
        try:
            df = pd.read_csv(uploaded_file)
            
            st.success("✅ File uploaded successfully!")
            
            # Display data preview
            st.markdown("### 👀 Data Preview")
            st.dataframe(df.head(), use_container_width=True)
            
            # Basic analysis
            if len(df) > 0:
                st.markdown("### 📊 Basic Analysis")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.metric("Total Projects", len(df))
                
                with col2:
                    if 'Agreement Amount' in df.columns:
                        total_value = pd.to_numeric(df['Agreement Amount'], errors='coerce').sum()
                        st.metric("Total Project Value", f"₹{total_value:,.0f}")
                
                # Generate analysis based on available columns
                if st.button("Perform Detailed Analysis"):
                    analyze_uploaded_data(df)
        
        except Exception as e:
            st.error(f"Error processing file: {str(e)}")

def analyze_uploaded_data(df):
    """Analyze uploaded project data"""
    
    st.markdown("### 📊 Detailed Analysis of Uploaded Data")
    
    # Identify numeric columns for analysis
    numeric_columns = df.select_dtypes(include=[np.number]).columns.tolist()
    
    if numeric_columns:
        st.markdown("#### 📈 Summary Statistics")
        summary_stats = df[numeric_columns].describe()
        st.dataframe(summary_stats.style.format("{:.2f}"), use_container_width=True)
    
    # Column analysis
    st.markdown("#### 📋 Column Information")
    column_info = []
    for col in df.columns:
        column_info.append({
            'Column': col,
            'Data Type': str(df[col].dtype),
            'Non-Null Count': df[col].count(),
            'Null Count': df[col].isnull().sum()
        })
    
    column_df = pd.DataFrame(column_info)
    st.dataframe(column_df, use_container_width=True)

def generate_project_analysis_report(project_name, physical_progress, financial_progress, outstanding_amount):
    """Generate downloadable project analysis report"""
    
    report_text = f"""
PROJECT FINANCIAL ANALYSIS REPORT
=================================

Project: {project_name}
Analysis Date: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}

KEY METRICS:
- Physical Progress: {physical_progress:.1f}%
- Financial Progress: {financial_progress:.1f}%
- Outstanding Amount: ₹{outstanding_amount:,.2f}

ANALYSIS SUMMARY:
Progress alignment between physical and financial work shows {"good" if abs(physical_progress - financial_progress) < 10 else "concerning"} correlation.

Generated by: PWD Tools - Financial Analysis
"""
    
    st.download_button(
        label="📄 Download Analysis Report (TXT)",
        data=report_text,
        file_name=f"financial_analysis_{project_name.replace(' ', '_')}_{datetime.now().strftime('%Y%m%d')}.txt",
        mime="text/plain",
        use_container_width=True
    )

if __name__ == "__main__":
    main()
