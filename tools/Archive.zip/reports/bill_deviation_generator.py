"""
Bill & Deviation Generator Tool
Generate bills and deviation reports for PWD projects
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, date, timedelta
import io

def main():
    """Main function for Bill & Deviation Generator tool"""
    st.markdown("### 🔧 Bill & Deviation Generator")
    st.markdown("Generate comprehensive bills and deviation analysis reports for PWD projects")
    
    # Tool mode selection
    tool_mode = st.radio(
        "Select Generation Mode:",
        ["Bill Generation", "Deviation Analysis", "Combined Report"]
    )
    
    if tool_mode == "Bill Generation":
        generate_bill()
    elif tool_mode == "Deviation Analysis":
        deviation_analysis()
    else:
        combined_report()

def generate_bill():
    """Generate detailed bills"""
    
    st.markdown("#### 📋 Bill Generation")
    
    with st.form("bill_generation_form"):
        # Basic bill information
        col1, col2 = st.columns(2)
        
        with col1:
            bill_number = st.text_input("Bill Number*", placeholder="Bill/Invoice number")
            bill_date = st.date_input("Bill Date*", value=date.today())
            bill_type = st.selectbox("Bill Type*", [
                "Select Type",
                "Running Account Bill",
                "Final Bill", 
                "Supplementary Bill",
                "Deviation Bill",
                "Extra Item Bill"
            ])
            period_from = st.date_input("Period From*")
        
        with col2:
            contractor_name = st.text_input("Contractor Name*", placeholder="Contractor name")
            work_order_no = st.text_input("Work Order No.*", placeholder="WO number")
            agreement_amount = st.number_input("Agreement Amount (₹)*", min_value=0.0, format="%.2f")
            period_to = st.date_input("Period To*", value=date.today())
        
        # Work details
        st.markdown("#### Work Details")
        work_description = st.text_area("Work Description*", height=100, placeholder="Detailed work description...")
        
        # Bill items
        st.markdown("#### Bill Items")
        
        # Initialize bill items in session state
        if 'bill_items' not in st.session_state:
            st.session_state.bill_items = []
        
        # Add item form
        with st.expander("➕ Add Bill Item", expanded=True):
            item_col1, item_col2, item_col3 = st.columns(3)
            
            with item_col1:
                item_description = st.text_input("Item Description", placeholder="Work item description")
                item_unit = st.selectbox("Unit", ["Nos", "Sqm", "Cum", "RMT", "MT", "LS", "Each"])
            
            with item_col2:
                item_quantity = st.number_input("Quantity", min_value=0.0, format="%.2f")
                item_rate = st.number_input("Rate (₹)", min_value=0.0, format="%.2f")
            
            with item_col3:
                item_total = item_quantity * item_rate
                st.metric("Total Amount", f"₹{item_total:,.2f}")
                
                if st.button("Add Item"):
                    if item_description and item_quantity > 0 and item_rate > 0:
                        new_item = {
                            'description': item_description,
                            'unit': item_unit,
                            'quantity': item_quantity,
                            'rate': item_rate,
                            'total': item_total
                        }
                        st.session_state.bill_items.append(new_item)
                        st.success("Item added!")
                        st.rerun()
        
        # Display current items
        if st.session_state.bill_items:
            st.markdown("##### Current Bill Items")
            items_df = pd.DataFrame(st.session_state.bill_items)
            items_df.index += 1
            st.dataframe(items_df, use_container_width=True)
            
            if st.button("Clear All Items"):
                st.session_state.bill_items = []
                st.rerun()
        
        submitted = st.form_submit_button("Generate Bill", use_container_width=True)
    
    if submitted:
        if not all([bill_number, contractor_name, work_order_no, bill_type != "Select Type"]):
            st.error("Please fill all required fields marked with *")
            return
        
        if not st.session_state.bill_items:
            st.error("Please add at least one bill item")
            return
        
        # Generate bill
        generate_detailed_bill(
            bill_number, bill_date, bill_type, contractor_name, work_order_no,
            agreement_amount, period_from, period_to, work_description,
            st.session_state.bill_items
        )

def generate_detailed_bill(bill_number, bill_date, bill_type, contractor_name, work_order_no,
                          agreement_amount, period_from, period_to, work_description, bill_items):
    """Generate detailed bill output"""
    
    # Calculate totals
    total_amount = sum([item['total'] for item in bill_items])
    
    st.success("✅ Bill generated successfully!")
    
    # Display bill
    st.markdown("---")
    st.markdown("## 📋 DETAILED BILL")
    
    # Header
    st.markdown(f"""
    <div style="text-align: center; border: 2px solid #004E89; padding: 20px; margin: 10px 0; background-color: #F8F9FA;">
        <h2 style="color: #004E89; margin: 0;">PWD BILL</h2>
        <h3 style="color: #FF6B35; margin: 5px 0;">Bill Number: {bill_number}</h3>
        <p style="margin: 5px 0;">Date: {bill_date.strftime('%d/%m/%Y')} | Type: {bill_type}</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Bill details
    info_col1, info_col2 = st.columns(2)
    
    with info_col1:
        st.markdown(f"""
        **Contractor:** {contractor_name}  
        **Work Order No.:** {work_order_no}  
        **Agreement Amount:** ₹{agreement_amount:,.2f}  
        **Period From:** {period_from.strftime('%d/%m/%Y')}
        """)
    
    with info_col2:
        st.markdown(f"""
        **Bill Type:** {bill_type}  
        **Period To:** {period_to.strftime('%d/%m/%Y')}  
        **Bill Amount:** ₹{total_amount:,.2f}  
        **Progress:** {(total_amount/agreement_amount*100):.1f}%
        """)
    
    # Work description
    st.markdown("**Work Description:**")
    st.write(work_description)
    
    # Bill items table
    st.markdown("### Bill Items")
    
    items_display = []
    for i, item in enumerate(bill_items, 1):
        items_display.append({
            'S.No.': i,
            'Description': item['description'],
            'Unit': item['unit'],
            'Quantity': f"{item['quantity']:.2f}",
            'Rate (₹)': f"{item['rate']:,.2f}",
            'Amount (₹)': f"{item['total']:,.2f}"
        })
    
    items_df = pd.DataFrame(items_display)
    st.table(items_df)
    
    # Summary
    st.markdown("### Bill Summary")
    
    summary_data = {
        'Description': ['Total Bill Amount', 'Agreement Amount', 'Balance Work', 'Progress %'],
        'Amount/Value': [
            f"₹{total_amount:,.2f}",
            f"₹{agreement_amount:,.2f}",
            f"₹{agreement_amount - total_amount:,.2f}",
            f"{(total_amount/agreement_amount*100):.1f}%"
        ]
    }
    
    summary_df = pd.DataFrame(summary_data)
    st.table(summary_df)
    
    # Generate downloads
    generate_bill_downloads(bill_number, bill_date, contractor_name, total_amount, items_df)

def deviation_analysis():
    """Perform deviation analysis"""
    
    st.markdown("#### 📊 Deviation Analysis")
    
    with st.form("deviation_analysis_form"):
        # Project information
        col1, col2 = st.columns(2)
        
        with col1:
            project_name = st.text_input("Project Name*", placeholder="Project name")
            original_estimate = st.number_input("Original Estimate (₹)*", min_value=0.0, format="%.2f")
            approved_amount = st.number_input("Approved Amount (₹)*", min_value=0.0, format="%.2f")
        
        with col2:
            project_code = st.text_input("Project Code", placeholder="Project ID")
            revised_estimate = st.number_input("Revised Estimate (₹)", min_value=0.0, format="%.2f")
            actual_expenditure = st.number_input("Actual Expenditure (₹)", min_value=0.0, format="%.2f")
        
        # Deviation details
        st.markdown("#### Deviation Details")
        
        deviation_type = st.selectbox("Primary Deviation Type", [
            "Quantity Variation",
            "Rate Revision", 
            "Extra Items",
            "Specification Change",
            "Site Conditions",
            "Design Changes"
        ])
        
        deviation_reason = st.text_area("Deviation Reason/Justification*", height=100,
                                      placeholder="Detailed explanation for deviations...")
        
        # Authorization details
        col3, col4 = st.columns(2)
        
        with col3:
            approval_authority = st.selectbox("Approval Authority", [
                "Executive Engineer",
                "Superintending Engineer", 
                "Chief Engineer",
                "Secretary PWD",
                "Government"
            ])
            approval_date = st.date_input("Approval Date", value=date.today())
        
        with col4:
            approval_number = st.text_input("Approval Number", placeholder="Authorization number")
            urgency_level = st.selectbox("Urgency Level", ["Normal", "High", "Critical"])
        
        submitted = st.form_submit_button("Analyze Deviations", use_container_width=True)
    
    if submitted:
        if not all([project_name, original_estimate > 0, approved_amount > 0, deviation_reason]):
            st.error("Please fill all required fields marked with *")
            return
        
        # Perform deviation analysis
        analyze_project_deviations(
            project_name, project_code, original_estimate, approved_amount,
            revised_estimate, actual_expenditure, deviation_type, deviation_reason,
            approval_authority, approval_date, approval_number, urgency_level
        )

def analyze_project_deviations(project_name, project_code, original_estimate, approved_amount,
                             revised_estimate, actual_expenditure, deviation_type, deviation_reason,
                             approval_authority, approval_date, approval_number, urgency_level):
    """Analyze and display project deviations"""
    
    # Calculate deviations
    estimate_deviation = revised_estimate - original_estimate if revised_estimate > 0 else 0
    expenditure_deviation = actual_expenditure - approved_amount if actual_expenditure > 0 else 0
    
    estimate_deviation_percent = (estimate_deviation / original_estimate * 100) if original_estimate > 0 else 0
    expenditure_deviation_percent = (expenditure_deviation / approved_amount * 100) if approved_amount > 0 else 0
    
    st.success("✅ Deviation analysis completed!")
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Original Estimate", f"₹{original_estimate:,.2f}")
    
    with col2:
        st.metric("Estimate Deviation", f"₹{estimate_deviation:,.2f}", 
                 delta=f"{estimate_deviation_percent:+.1f}%")
    
    with col3:
        st.metric("Approved Amount", f"₹{approved_amount:,.2f}")
    
    with col4:
        st.metric("Expenditure Deviation", f"₹{expenditure_deviation:,.2f}",
                 delta=f"{expenditure_deviation_percent:+.1f}%")
    
    # Detailed analysis
    st.markdown("---")
    st.markdown("## 📊 DEVIATION ANALYSIS REPORT")
    
    # Project information
    info_col1, info_col2 = st.columns(2)
    
    with info_col1:
        st.markdown(f"""
        **Project Name:** {project_name}  
        **Project Code:** {project_code}  
        **Deviation Type:** {deviation_type}  
        **Urgency Level:** {urgency_level}
        """)
    
    with info_col2:
        st.markdown(f"""
        **Approval Authority:** {approval_authority}  
        **Approval Date:** {approval_date.strftime('%d/%m/%Y')}  
        **Approval Number:** {approval_number}
        """)
    
    # Financial analysis
    st.markdown("### Financial Analysis")
    
    financial_data = {
        'Component': [
            'Original Estimate',
            'Revised Estimate', 
            'Estimate Deviation',
            'Approved Amount',
            'Actual Expenditure',
            'Expenditure Deviation'
        ],
        'Amount (₹)': [
            f"{original_estimate:,.2f}",
            f"{revised_estimate:,.2f}" if revised_estimate > 0 else "Not Revised",
            f"{estimate_deviation:,.2f}",
            f"{approved_amount:,.2f}",
            f"{actual_expenditure:,.2f}" if actual_expenditure > 0 else "In Progress",
            f"{expenditure_deviation:,.2f}"
        ],
        'Deviation %': [
            "Base",
            f"{estimate_deviation_percent:+.1f}%" if revised_estimate > 0 else "-",
            f"{estimate_deviation_percent:+.1f}%",
            "Approved",
            f"{expenditure_deviation_percent:+.1f}%" if actual_expenditure > 0 else "-",
            f"{expenditure_deviation_percent:+.1f}%"
        ]
    }
    
    financial_df = pd.DataFrame(financial_data)
    st.table(financial_df)
    
    # Deviation visualization
    create_deviation_charts(original_estimate, revised_estimate, approved_amount, actual_expenditure)
    
    # Deviation justification
    st.markdown("### Deviation Justification")
    st.write(deviation_reason)
    
    # Impact assessment
    assess_deviation_impact(estimate_deviation_percent, expenditure_deviation_percent)
    
    # Generate deviation report
    generate_deviation_report(
        project_name, original_estimate, estimate_deviation, 
        expenditure_deviation, deviation_type, approval_authority
    )

def create_deviation_charts(original_estimate, revised_estimate, approved_amount, actual_expenditure):
    """Create deviation visualization charts"""
    
    st.markdown("### Deviation Visualization")
    
    # Prepare data for charts
    estimates_data = {
        'Stage': ['Original Estimate', 'Revised Estimate', 'Approved Amount', 'Actual Expenditure'],
        'Amount': [
            original_estimate,
            revised_estimate if revised_estimate > 0 else original_estimate,
            approved_amount,
            actual_expenditure if actual_expenditure > 0 else approved_amount
        ]
    }
    
    # Bar chart comparing different stages
    fig_bar = px.bar(
        estimates_data,
        x='Stage',
        y='Amount',
        title='Project Cost Comparison',
        color='Stage',
        color_discrete_sequence=['#FF6B35', '#004E89', '#1A8A16', '#DC143C']
    )
    
    fig_bar.update_layout(height=400, showlegend=False)
    st.plotly_chart(fig_bar, use_container_width=True)
    
    # Deviation waterfall chart
    if revised_estimate > 0 or actual_expenditure > 0:
        create_waterfall_chart(original_estimate, revised_estimate, approved_amount, actual_expenditure)

def create_waterfall_chart(original_estimate, revised_estimate, approved_amount, actual_expenditure):
    """Create waterfall chart for deviations"""
    
    # Calculate cumulative values for waterfall
    values = [original_estimate]
    
    if revised_estimate > 0:
        estimate_change = revised_estimate - original_estimate
        values.append(estimate_change)
        values.append(revised_estimate)
    
    approval_change = approved_amount - (revised_estimate if revised_estimate > 0 else original_estimate)
    values.append(approval_change)
    values.append(approved_amount)
    
    if actual_expenditure > 0:
        expenditure_change = actual_expenditure - approved_amount
        values.append(expenditure_change)
        values.append(actual_expenditure)
    
    # Create labels
    labels = ['Original Estimate']
    
    if revised_estimate > 0:
        labels.extend(['Estimate Change', 'Revised Estimate'])
    
    labels.extend(['Approval Change', 'Approved Amount'])
    
    if actual_expenditure > 0:
        labels.extend(['Expenditure Change', 'Final Expenditure'])
    
    # Waterfall chart using Plotly
    fig_waterfall = go.Figure(go.Waterfall(
        name="Cost Evolution",
        orientation="v",
        measure=["absolute"] + ["relative"] * (len(values) - 1),
        x=labels[:len(values)],
        y=values,
        connector={"line": {"color": "rgb(63, 63, 63)"}},
        increasing={"marker": {"color": "#FF6B35"}},
        decreasing={"marker": {"color": "#1A8A16"}},
        totals={"marker": {"color": "#004E89"}}
    ))
    
    fig_waterfall.update_layout(
        title="Cost Evolution Waterfall Chart",
        height=400
    )
    
    st.plotly_chart(fig_waterfall, use_container_width=True)

def assess_deviation_impact(estimate_deviation_percent, expenditure_deviation_percent):
    """Assess the impact of deviations"""
    
    st.markdown("### Impact Assessment")
    
    # Define impact levels
    def get_impact_level(deviation_percent):
        if abs(deviation_percent) < 5:
            return "Low", "🟢"
        elif abs(deviation_percent) < 15:
            return "Medium", "🟡"
        elif abs(deviation_percent) < 25:
            return "High", "🟠"
        else:
            return "Critical", "🔴"
    
    estimate_impact, estimate_icon = get_impact_level(estimate_deviation_percent)
    expenditure_impact, expenditure_icon = get_impact_level(expenditure_deviation_percent)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown(f"""
        **Estimate Deviation Impact**  
        {estimate_icon} **{estimate_impact}** ({estimate_deviation_percent:+.1f}%)
        """)
    
    with col2:
        st.markdown(f"""
        **Expenditure Deviation Impact**  
        {expenditure_icon} **{expenditure_impact}** ({expenditure_deviation_percent:+.1f}%)
        """)
    
    # Recommendations based on impact
    st.markdown("#### Recommendations")
    
    if estimate_impact in ["High", "Critical"]:
        st.warning("""
        **High Estimate Deviation Detected:**
        - Review project scope and specifications
        - Obtain necessary approvals for cost escalation
        - Consider value engineering to optimize costs
        """)
    
    if expenditure_impact in ["High", "Critical"]:
        st.error("""
        **Critical Expenditure Deviation:**
        - Immediate review of project execution
        - Cost control measures implementation required
        - Senior management approval needed for continuation
        """)
    
    if estimate_impact == "Low" and expenditure_impact == "Low":
        st.success("""
        **Deviation within Acceptable Limits:**
        - Project is proceeding as planned
        - Continue monitoring for future deviations
        - Maintain current cost control measures
        """)

def combined_report():
    """Generate combined bill and deviation report"""
    
    st.markdown("#### 📊 Combined Bill & Deviation Report")
    
    st.info("This mode combines bill generation with deviation analysis for comprehensive reporting")
    
    # Use data from previous sections if available
    if 'bill_items' in st.session_state and st.session_state.bill_items:
        st.markdown("### 📋 Previous Bill Data Available")
        
        total_bill_amount = sum([item['total'] for item in st.session_state.bill_items])
        st.metric("Total Bill Amount", f"₹{total_bill_amount:,.2f}")
        
        # Quick deviation analysis
        with st.form("quick_deviation_form"):
            original_estimate = st.number_input("Original Estimate for Comparison (₹)", min_value=0.0, format="%.2f")
            
            if st.form_submit_button("Generate Combined Report"):
                if original_estimate > 0:
                    generate_combined_analysis(total_bill_amount, original_estimate)
                else:
                    st.error("Please enter original estimate for comparison")
    else:
        st.warning("No bill data available. Please generate a bill first using the 'Bill Generation' mode.")

def generate_combined_analysis(total_bill_amount, original_estimate):
    """Generate combined analysis"""
    
    st.markdown("## 📊 COMBINED BILL & DEVIATION ANALYSIS")
    
    # Calculate basic deviation
    deviation = total_bill_amount - original_estimate
    deviation_percent = (deviation / original_estimate * 100) if original_estimate > 0 else 0
    
    # Summary
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Original Estimate", f"₹{original_estimate:,.2f}")
    
    with col2:
        st.metric("Current Bill", f"₹{total_bill_amount:,.2f}")
    
    with col3:
        st.metric("Deviation", f"₹{deviation:,.2f}", delta=f"{deviation_percent:+.1f}%")
    
    # Combined analysis
    analysis_data = {
        'Component': ['Original Estimate', 'Current Bill Amount', 'Deviation', 'Deviation %'],
        'Value': [
            f"₹{original_estimate:,.2f}",
            f"₹{total_bill_amount:,.2f}",
            f"₹{deviation:,.2f}",
            f"{deviation_percent:+.1f}%"
        ]
    }
    
    analysis_df = pd.DataFrame(analysis_data)
    st.table(analysis_df)

def generate_bill_downloads(bill_number, bill_date, contractor_name, total_amount, items_df):
    """Generate downloadable bill reports"""
    
    # CSV download
    csv_data = items_df.to_csv(index=False)
    
    st.download_button(
        label="📥 Download Bill Items (CSV)",
        data=csv_data,
        file_name=f"bill_{bill_number}_{datetime.now().strftime('%Y%m%d')}.csv",
        mime="text/csv",
        use_container_width=True
    )

def generate_deviation_report(project_name, original_estimate, estimate_deviation, 
                            expenditure_deviation, deviation_type, approval_authority):
    """Generate downloadable deviation report"""
    
    report_text = f"""
DEVIATION ANALYSIS REPORT
========================

Project: {project_name}
Date: {datetime.now().strftime('%d/%m/%Y')}

FINANCIAL SUMMARY:
- Original Estimate: ₹{original_estimate:,.2f}
- Estimate Deviation: ₹{estimate_deviation:,.2f}
- Expenditure Deviation: ₹{expenditure_deviation:,.2f}

DEVIATION DETAILS:
- Type: {deviation_type}
- Approval Authority: {approval_authority}

Generated by: PWD Tools - Bill & Deviation Generator
"""
    
    st.download_button(
        label="📄 Download Deviation Report (TXT)",
        data=report_text,
        file_name=f"deviation_report_{datetime.now().strftime('%Y%m%d')}.txt",
        mime="text/plain",
        use_container_width=True
    )

if __name__ == "__main__":
    main()
