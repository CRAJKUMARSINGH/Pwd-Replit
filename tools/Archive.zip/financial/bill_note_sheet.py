"""
Bill Note Sheet Tool
Financial documentation and bill processing
"""

import streamlit as st
import pandas as pd
from datetime import datetime, date
import io

def main():
    """Main function for Bill Note Sheet tool"""
    st.markdown("### 📋 Bill Note Sheet Generator")
    st.markdown("Create and manage bill note sheets for financial documentation")
    
    # Input form
    with st.form("bill_note_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            project_name = st.text_input("Project Name*", placeholder="Enter project name")
            contractor_name = st.text_input("Contractor Name*", placeholder="Enter contractor name")
            bill_number = st.text_input("Bill Number*", placeholder="Bill No.")
            bill_date = st.date_input("Bill Date*", value=date.today())
        
        with col2:
            work_order_no = st.text_input("Work Order No.*", placeholder="WO Number")
            agreement_amount = st.number_input("Agreement Amount (₹)*", min_value=0.0, format="%.2f")
            bill_amount = st.number_input("Bill Amount (₹)*", min_value=0.0, format="%.2f")
            bill_period = st.text_input("Bill Period", placeholder="Month/Quarter")
        
        # Work description
        work_description = st.text_area("Work Description", height=100, placeholder="Describe the work completed...")
        
        # Deductions section
        st.markdown("#### Deductions")
        col3, col4, col5 = st.columns(3)
        
        with col3:
            income_tax = st.number_input("Income Tax (₹)", min_value=0.0, format="%.2f")
            gst_deduction = st.number_input("GST Deduction (₹)", min_value=0.0, format="%.2f")
        
        with col4:
            security_deposit = st.number_input("Security Deposit (₹)", min_value=0.0, format="%.2f")
            other_deductions = st.number_input("Other Deductions (₹)", min_value=0.0, format="%.2f")
        
        with col5:
            advance_deduction = st.number_input("Advance Deduction (₹)", min_value=0.0, format="%.2f")
            penalty = st.number_input("Penalty (₹)", min_value=0.0, format="%.2f")
        
        # Submit button
        submitted = st.form_submit_button("Generate Bill Note Sheet", use_container_width=True)
    
    if submitted:
        if not all([project_name, contractor_name, bill_number, work_order_no]):
            st.error("Please fill all required fields marked with *")
            return
        
        # Calculate totals
        total_deductions = income_tax + gst_deduction + security_deposit + other_deductions + advance_deduction + penalty
        net_amount = bill_amount - total_deductions
        
        # Generate bill note sheet
        generate_bill_note_sheet(
            project_name, contractor_name, bill_number, bill_date,
            work_order_no, agreement_amount, bill_amount, bill_period,
            work_description, total_deductions, net_amount,
            {
                'Income Tax': income_tax,
                'GST Deduction': gst_deduction,
                'Security Deposit': security_deposit,
                'Other Deductions': other_deductions,
                'Advance Deduction': advance_deduction,
                'Penalty': penalty
            }
        )

def generate_bill_note_sheet(project_name, contractor_name, bill_number, bill_date,
                           work_order_no, agreement_amount, bill_amount, bill_period,
                           work_description, total_deductions, net_amount, deductions_dict):
    """Generate and display bill note sheet"""
    
    st.success("✅ Bill Note Sheet generated successfully!")
    
    # Display bill note sheet
    st.markdown("---")
    st.markdown("## 📋 BILL NOTE SHEET")
    
    # Header information
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown(f"""
        **Project:** {project_name}  
        **Contractor:** {contractor_name}  
        **Work Order No.:** {work_order_no}  
        **Agreement Amount:** ₹{agreement_amount:,.2f}
        """)
    
    with col2:
        st.markdown(f"""
        **Bill No.:** {bill_number}  
        **Bill Date:** {bill_date.strftime('%d/%m/%Y')}  
        **Bill Period:** {bill_period}  
        **Bill Amount:** ₹{bill_amount:,.2f}
        """)
    
    # Work description
    if work_description:
        st.markdown("**Work Description:**")
        st.write(work_description)
    
    # Deductions table
    st.markdown("### Deductions Breakdown")
    
    deductions_data = []
    for key, value in deductions_dict.items():
        if value > 0:
            deductions_data.append({"Deduction Type": key, "Amount (₹)": f"{value:,.2f}"})
    
    if deductions_data:
        df_deductions = pd.DataFrame(deductions_data)
        st.table(df_deductions)
    else:
        st.info("No deductions applied")
    
    # Summary
    st.markdown("### Summary")
    summary_df = pd.DataFrame({
        'Description': ['Bill Amount', 'Total Deductions', 'Net Payable Amount'],
        'Amount (₹)': [f"{bill_amount:,.2f}", f"{total_deductions:,.2f}", f"{net_amount:,.2f}"]
    })
    st.table(summary_df)
    
    # Generate downloadable report
    generate_downloadable_report(
        project_name, contractor_name, bill_number, bill_date,
        work_order_no, agreement_amount, bill_amount, net_amount
    )

def generate_downloadable_report(project_name, contractor_name, bill_number, bill_date,
                               work_order_no, agreement_amount, bill_amount, net_amount):
    """Generate downloadable CSV report"""
    
    # Create report data
    report_data = {
        'Field': ['Project Name', 'Contractor Name', 'Bill Number', 'Bill Date', 
                 'Work Order No.', 'Agreement Amount', 'Bill Amount', 'Net Payable Amount'],
        'Value': [project_name, contractor_name, bill_number, bill_date.strftime('%d/%m/%Y'),
                 work_order_no, f"₹{agreement_amount:,.2f}", f"₹{bill_amount:,.2f}", f"₹{net_amount:,.2f}"]
    }
    
    df = pd.DataFrame(report_data)
    
    # Convert to CSV
    csv = df.to_csv(index=False)
    
    # Download button
    st.download_button(
        label="📥 Download Bill Note Sheet (CSV)",
        data=csv,
        file_name=f"bill_note_sheet_{bill_number}_{datetime.now().strftime('%Y%m%d')}.csv",
        mime="text/csv",
        use_container_width=True
    )

if __name__ == "__main__":
    main()
