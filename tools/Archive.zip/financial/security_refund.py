"""
Security Refund Tool
Security deposit refund processing
"""

import streamlit as st
import pandas as pd
from datetime import datetime, date, timedelta

def main():
    """Main function for Security Refund tool"""
    st.markdown("### 🔒 Security Refund Calculator")
    st.markdown("Calculate and process security deposit refunds for completed contracts")
    
    # Input form
    with st.form("security_refund_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            contract_no = st.text_input("Contract Number*", placeholder="Enter contract number")
            contractor_name = st.text_input("Contractor Name*", placeholder="Enter contractor name")
            security_amount = st.number_input("Security Deposit Amount (₹)*", min_value=0.0, format="%.2f")
            deposit_date = st.date_input("Security Deposit Date*", value=date.today() - timedelta(days=365))
        
        with col2:
            completion_date = st.date_input("Work Completion Date*", value=date.today() - timedelta(days=30))
            refund_date = st.date_input("Refund Processing Date*", value=date.today())
            contract_value = st.number_input("Contract Value (₹)", min_value=0.0, format="%.2f")
            defect_liability_period = st.number_input("Defect Liability Period (Months)", min_value=0, max_value=60, value=12)
        
        # Work completion details
        st.markdown("#### Work Completion Details")
        work_status = st.selectbox("Work Status*", [
            "Select Status",
            "Completed Satisfactorily",
            "Completed with Minor Issues",
            "Under Defect Liability Period",
            "DLP Expired - All Clear"
        ])
        
        final_bill_cleared = st.checkbox("Final Bill Cleared")
        no_outstanding_dues = st.checkbox("No Outstanding Dues")
        defect_liability_expired = st.checkbox("Defect Liability Period Expired")
        
        # Deductions
        st.markdown("#### Deductions (if any)")
        col3, col4 = st.columns(2)
        
        with col3:
            penalty_deduction = st.number_input("Penalty Deduction (₹)", min_value=0.0, format="%.2f")
            damage_deduction = st.number_input("Damage Deduction (₹)", min_value=0.0, format="%.2f")
        
        with col4:
            outstanding_dues = st.number_input("Outstanding Dues (₹)", min_value=0.0, format="%.2f")
            other_deductions = st.number_input("Other Deductions (₹)", min_value=0.0, format="%.2f")
        
        remarks = st.text_area("Remarks/Notes", height=80, placeholder="Any additional information...")
        
        # Submit button
        submitted = st.form_submit_button("Calculate Security Refund", use_container_width=True)
    
    if submitted:
        if not all([contract_no, contractor_name, security_amount > 0, work_status != "Select Status"]):
            st.error("Please fill all required fields marked with *")
            return
        
        # Calculate refund
        calculate_security_refund(
            contract_no, contractor_name, security_amount, deposit_date,
            completion_date, refund_date, contract_value, defect_liability_period,
            work_status, final_bill_cleared, no_outstanding_dues, defect_liability_expired,
            penalty_deduction, damage_deduction, outstanding_dues, other_deductions, remarks
        )

def calculate_security_refund(contract_no, contractor_name, security_amount, deposit_date,
                             completion_date, refund_date, contract_value, defect_liability_period,
                             work_status, final_bill_cleared, no_outstanding_dues, defect_liability_expired,
                             penalty_deduction, damage_deduction, outstanding_dues, other_deductions, remarks):
    """Calculate security refund amount"""
    
    # Calculate total deductions
    total_deductions = penalty_deduction + damage_deduction + outstanding_dues + other_deductions
    
    # Calculate refundable amount
    refundable_amount = security_amount - total_deductions
    
    # Check eligibility
    eligibility_checks = {
        "Work Completed": work_status in ["Completed Satisfactorily", "Completed with Minor Issues", "DLP Expired - All Clear"],
        "Final Bill Cleared": final_bill_cleared,
        "No Outstanding Dues": no_outstanding_dues,
        "DLP Status": defect_liability_expired or work_status == "DLP Expired - All Clear"
    }
    
    eligible_for_refund = all(eligibility_checks.values())
    
    # Calculate days held
    days_held = (refund_date - deposit_date).days
    
    # Display results
    if eligible_for_refund and refundable_amount > 0:
        st.success("✅ Security deposit is eligible for refund!")
    elif not eligible_for_refund:
        st.warning("⚠️ Security deposit refund conditions not fully met.")
    else:
        st.error("❌ Refund amount is zero or negative due to deductions.")
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Security Amount", f"₹{security_amount:,.2f}")
    
    with col2:
        st.metric("Total Deductions", f"₹{total_deductions:,.2f}")
    
    with col3:
        st.metric("Refundable Amount", f"₹{refundable_amount:,.2f}")
    
    with col4:
        st.metric("Days Held", f"{days_held} days")
    
    # Detailed refund sheet
    st.markdown("---")
    st.markdown("## 🔒 SECURITY REFUND SHEET")
    
    # Contract information
    info_col1, info_col2 = st.columns(2)
    
    with info_col1:
        st.markdown(f"""
        **Contract Number:** {contract_no}  
        **Contractor Name:** {contractor_name}  
        **Security Amount:** ₹{security_amount:,.2f}  
        **Deposit Date:** {deposit_date.strftime('%d/%m/%Y')}  
        **Contract Value:** ₹{contract_value:,.2f}
        """)
    
    with info_col2:
        st.markdown(f"""
        **Completion Date:** {completion_date.strftime('%d/%m/%Y')}  
        **Refund Date:** {refund_date.strftime('%d/%m/%Y')}  
        **Work Status:** {work_status}  
        **DLP Period:** {defect_liability_period} months  
        **Days Held:** {days_held} days
        """)
    
    # Eligibility checklist
    st.markdown("### Eligibility Checklist")
    
    checklist_data = []
    for check, status in eligibility_checks.items():
        checklist_data.append({
            "Criteria": check,
            "Status": "✅ Met" if status else "❌ Not Met"
        })
    
    df_checklist = pd.DataFrame(checklist_data)
    st.table(df_checklist)
    
    # Deductions breakdown
    if total_deductions > 0:
        st.markdown("### Deductions Breakdown")
        
        deductions_data = []
        if penalty_deduction > 0:
            deductions_data.append({"Type": "Penalty Deduction", "Amount (₹)": f"{penalty_deduction:,.2f}"})
        if damage_deduction > 0:
            deductions_data.append({"Type": "Damage Deduction", "Amount (₹)": f"{damage_deduction:,.2f}"})
        if outstanding_dues > 0:
            deductions_data.append({"Type": "Outstanding Dues", "Amount (₹)": f"{outstanding_dues:,.2f}"})
        if other_deductions > 0:
            deductions_data.append({"Type": "Other Deductions", "Amount (₹)": f"{other_deductions:,.2f}"})
        
        if deductions_data:
            df_deductions = pd.DataFrame(deductions_data)
            st.table(df_deductions)
    
    # Final calculation
    st.markdown("### Final Calculation")
    
    calc_data = {
        'Component': ['Security Deposit Amount', 'Less: Total Deductions', 'Net Refundable Amount'],
        'Amount (₹)': [f"{security_amount:,.2f}", f"{total_deductions:,.2f}", f"{refundable_amount:,.2f}"]
    }
    
    df_calc = pd.DataFrame(calc_data)
    st.table(df_calc)
    
    # Remarks
    if remarks:
        st.markdown("### Remarks")
        st.write(remarks)
    
    # Generate refund order
    generate_security_refund_order(
        contract_no, contractor_name, security_amount, refundable_amount,
        total_deductions, work_status, eligible_for_refund, days_held
    )

def generate_security_refund_order(contract_no, contractor_name, security_amount, refundable_amount,
                                  total_deductions, work_status, eligible_for_refund, days_held):
    """Generate downloadable security refund order"""
    
    # Create refund order data
    refund_data = {
        'Field': [
            'Contract Number', 'Contractor Name', 'Security Deposit Amount', 'Total Deductions',
            'Net Refundable Amount', 'Work Status', 'Days Held', 'Eligible for Refund'
        ],
        'Details': [
            contract_no, contractor_name, f"₹{security_amount:,.2f}", f"₹{total_deductions:,.2f}",
            f"₹{refundable_amount:,.2f}", work_status, f"{days_held} days",
            "Yes" if eligible_for_refund else "No"
        ]
    }
    
    df = pd.DataFrame(refund_data)
    
    # Convert to CSV
    csv = df.to_csv(index=False)
    
    # Download button
    st.download_button(
        label="📥 Download Security Refund Order (CSV)",
        data=csv,
        file_name=f"security_refund_{contract_no}_{datetime.now().strftime('%Y%m%d')}.csv",
        mime="text/csv",
        use_container_width=True
    )

if __name__ == "__main__":
    main()
