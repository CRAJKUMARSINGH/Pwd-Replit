"""
EMD Refund Tool
Earnest Money Deposit refund processing
"""

import streamlit as st
import pandas as pd
from datetime import datetime, date, timedelta
import io

def main():
    """Main function for EMD Refund tool"""
    st.markdown("### 💰 EMD Refund Calculator")
    st.markdown("Calculate and process Earnest Money Deposit refunds with interest")
    
    # Input form
    with st.form("emd_refund_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            tender_no = st.text_input("Tender Number*", placeholder="Enter tender number")
            contractor_name = st.text_input("Contractor/Bidder Name*", placeholder="Enter name")
            emd_amount = st.number_input("EMD Amount (₹)*", min_value=0.0, format="%.2f")
            deposit_date = st.date_input("EMD Deposit Date*", value=date.today() - timedelta(days=30))
        
        with col2:
            refund_date = st.date_input("Refund Date*", value=date.today())
            interest_rate = st.number_input("Interest Rate (%)*", min_value=0.0, max_value=20.0, value=6.0, format="%.2f")
            refund_reason = st.selectbox("Refund Reason*", [
                "Select Reason",
                "Tender Cancelled",
                "Work Completed",
                "Bid Rejected",
                "Contractor Withdrawal",
                "Other"
            ])
            bank_details = st.text_input("Bank Account Details", placeholder="Account number for refund")
        
        # Additional details
        remarks = st.text_area("Remarks/Notes", height=80, placeholder="Any additional information...")
        
        # Submit button
        submitted = st.form_submit_button("Calculate EMD Refund", use_container_width=True)
    
    if submitted:
        if not all([tender_no, contractor_name, emd_amount > 0, refund_reason != "Select Reason"]):
            st.error("Please fill all required fields marked with *")
            return
        
        # Calculate refund details
        calculate_emd_refund(
            tender_no, contractor_name, emd_amount, deposit_date,
            refund_date, interest_rate, refund_reason, bank_details, remarks
        )

def calculate_emd_refund(tender_no, contractor_name, emd_amount, deposit_date,
                        refund_date, interest_rate, refund_reason, bank_details, remarks):
    """Calculate EMD refund with interest"""
    
    # Calculate number of days
    days_held = (refund_date - deposit_date).days
    
    # Calculate interest
    if days_held > 0:
        annual_interest = (emd_amount * interest_rate * days_held) / (365 * 100)
    else:
        annual_interest = 0
    
    # Total refund amount
    total_refund = emd_amount + annual_interest
    
    # Display results
    st.success("✅ EMD Refund calculated successfully!")
    
    # Summary cards
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("EMD Amount", f"₹{emd_amount:,.2f}")
    
    with col2:
        st.metric("Days Held", f"{days_held} days")
    
    with col3:
        st.metric("Interest Amount", f"₹{annual_interest:,.2f}")
    
    with col4:
        st.metric("Total Refund", f"₹{total_refund:,.2f}", delta=f"₹{annual_interest:,.2f}")
    
    # Detailed refund sheet
    st.markdown("---")
    st.markdown("## 💰 EMD REFUND SHEET")
    
    # Basic information
    info_col1, info_col2 = st.columns(2)
    
    with info_col1:
        st.markdown(f"""
        **Tender Number:** {tender_no}  
        **Contractor/Bidder:** {contractor_name}  
        **EMD Amount:** ₹{emd_amount:,.2f}  
        **Deposit Date:** {deposit_date.strftime('%d/%m/%Y')}
        """)
    
    with info_col2:
        st.markdown(f"""
        **Refund Date:** {refund_date.strftime('%d/%m/%Y')}  
        **Days Held:** {days_held} days  
        **Interest Rate:** {interest_rate}% per annum  
        **Refund Reason:** {refund_reason}
        """)
    
    # Bank details
    if bank_details:
        st.markdown(f"**Bank Account Details:** {bank_details}")
    
    # Calculation breakdown
    st.markdown("### Calculation Breakdown")
    
    calc_data = {
        'Component': ['Principal EMD Amount', 'Interest Calculation', 'Days Held', 'Interest Amount', 'Total Refund Amount'],
        'Details': [
            f"₹{emd_amount:,.2f}",
            f"₹{emd_amount:,.2f} × {interest_rate}% × {days_held}/365",
            f"{days_held} days",
            f"₹{annual_interest:,.2f}",
            f"₹{total_refund:,.2f}"
        ]
    }
    
    df_calc = pd.DataFrame(calc_data)
    st.table(df_calc)
    
    # Remarks
    if remarks:
        st.markdown("### Remarks")
        st.write(remarks)
    
    # Generate refund order
    generate_refund_order(
        tender_no, contractor_name, emd_amount, deposit_date,
        refund_date, interest_rate, total_refund, refund_reason, days_held, annual_interest
    )

def generate_refund_order(tender_no, contractor_name, emd_amount, deposit_date,
                         refund_date, interest_rate, total_refund, refund_reason, days_held, interest_amount):
    """Generate downloadable refund order"""
    
    # Create refund order data
    refund_data = {
        'Field': [
            'Tender Number', 'Contractor/Bidder Name', 'EMD Amount', 'Deposit Date',
            'Refund Date', 'Days Held', 'Interest Rate', 'Interest Amount',
            'Total Refund Amount', 'Refund Reason'
        ],
        'Details': [
            tender_no, contractor_name, f"₹{emd_amount:,.2f}", deposit_date.strftime('%d/%m/%Y'),
            refund_date.strftime('%d/%m/%Y'), f"{days_held} days", f"{interest_rate}%",
            f"₹{interest_amount:,.2f}", f"₹{total_refund:,.2f}", refund_reason
        ]
    }
    
    df = pd.DataFrame(refund_data)
    
    # Convert to CSV
    csv = df.to_csv(index=False)
    
    # Download button
    st.download_button(
        label="📥 Download EMD Refund Order (CSV)",
        data=csv,
        file_name=f"emd_refund_{tender_no}_{datetime.now().strftime('%Y%m%d')}.csv",
        mime="text/csv",
        use_container_width=True
    )
    
    # Additional download - detailed calculation
    detailed_calc = f"""
EMD REFUND CALCULATION SHEET
============================

Tender Number: {tender_no}
Contractor/Bidder: {contractor_name}
Refund Reason: {refund_reason}

FINANCIAL DETAILS:
- EMD Amount: ₹{emd_amount:,.2f}
- Deposit Date: {deposit_date.strftime('%d/%m/%Y')}
- Refund Date: {refund_date.strftime('%d/%m/%Y')}
- Days Held: {days_held} days

INTEREST CALCULATION:
- Interest Rate: {interest_rate}% per annum
- Formula: Principal × Rate × Days ÷ (365 × 100)
- Calculation: ₹{emd_amount:,.2f} × {interest_rate}% × {days_held} ÷ 365
- Interest Amount: ₹{interest_amount:,.2f}

TOTAL REFUND: ₹{total_refund:,.2f}

Generated on: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
PWD Tools - EMD Refund Calculator
"""
    
    st.download_button(
        label="📄 Download Detailed Calculation (TXT)",
        data=detailed_calc,
        file_name=f"emd_refund_detailed_{tender_no}_{datetime.now().strftime('%Y%m%d')}.txt",
        mime="text/plain",
        use_container_width=True
    )

if __name__ == "__main__":
    main()
