"""
Hindi Bill Generator Tool
Generate bills and documents in Hindi for PWD operations
"""

import streamlit as st
import pandas as pd
from datetime import datetime, date
import io

def main():
    """Main function for Hindi Bill Generator tool"""
    st.markdown("### 🇮🇳 Hindi Bill Generator")
    st.markdown("Generate bills and financial documents in Hindi for PWD operations")
    
    # Document type selection
    doc_type = st.selectbox(
        "Document Type / दस्तावेज़ प्रकार:",
        ["Select Type", "Bill / बिल", "Payment Order / भुगतान आदेश", "Work Order / कार्य आदेश", "Completion Certificate / पूर्णता प्रमाणपत्र"]
    )
    
    if doc_type == "Bill / बिल":
        generate_hindi_bill()
    elif doc_type == "Payment Order / भुगतान आदेश":
        generate_payment_order()
    elif doc_type == "Work Order / कार्य आदेश":
        generate_work_order()
    elif doc_type == "Completion Certificate / पूर्णता प्रमाणपत्र":
        generate_completion_certificate()
    else:
        st.info("Please select a document type to begin / कृपया आरंभ करने के लिए दस्तावेज़ प्रकार चुनें")

def generate_hindi_bill():
    """Generate Hindi bill"""
    
    st.markdown("#### 📋 Bill Generation / बिल निर्माण")
    
    with st.form("hindi_bill_form"):
        # Basic information
        col1, col2 = st.columns(2)
        
        with col1:
            bill_no = st.text_input("Bill Number / बिल संख्या*")
            bill_date = st.date_input("Bill Date / बिल दिनांक*", value=date.today())
            contractor_name = st.text_input("Contractor Name / ठेकेदार का नाम*")
            work_description = st.text_area("Work Description / कार्य विवरण*", height=100)
        
        with col2:
            work_order_no = st.text_input("Work Order No. / कार्य आदेश संख्या*")
            agreement_amount = st.number_input("Agreement Amount / समझौता राशि (₹)*", min_value=0.0, format="%.2f")
            bill_amount = st.number_input("Bill Amount / बिल राशि (₹)*", min_value=0.0, format="%.2f")
            period = st.text_input("Period / अवधि", placeholder="महीना/तिमाही")
        
        # Location details
        st.markdown("**Location Details / स्थान विवरण**")
        col3, col4 = st.columns(2)
        
        with col3:
            district = st.text_input("District / जिला", value="उदयपुर")
            tehsil = st.text_input("Tehsil / तहसील")
        
        with col4:
            village = st.text_input("Village / गांव")
            office = st.text_input("Office / कार्यालय", value="लोक निर्माण विभाग, उदयपुर")
        
        # Deductions
        st.markdown("**Deductions / कटौतियां**")
        col5, col6 = st.columns(2)
        
        with col5:
            income_tax = st.number_input("Income Tax / आयकर (₹)", min_value=0.0, format="%.2f")
            labour_cess = st.number_input("Labour Cess / श्रमिक उपकर (₹)", min_value=0.0, format="%.2f")
        
        with col6:
            security_deposit = st.number_input("Security Deposit / जमानत राशि (₹)", min_value=0.0, format="%.2f")
            other_deductions = st.number_input("Other Deductions / अन्य कटौतियां (₹)", min_value=0.0, format="%.2f")
        
        submitted = st.form_submit_button("Generate Hindi Bill / हिंदी बिल तैयार करें", use_container_width=True)
    
    if submitted:
        if not all([bill_no, contractor_name, work_description, work_order_no]):
            st.error("Please fill all required fields / कृपया सभी आवश्यक फ़ील्ड भरें")
            return
        
        # Calculate totals
        total_deductions = income_tax + labour_cess + security_deposit + other_deductions
        net_amount = bill_amount - total_deductions
        
        # Display Hindi bill
        display_hindi_bill(
            bill_no, bill_date, contractor_name, work_description, work_order_no,
            agreement_amount, bill_amount, period, district, tehsil, village, office,
            income_tax, labour_cess, security_deposit, other_deductions,
            total_deductions, net_amount
        )

def display_hindi_bill(bill_no, bill_date, contractor_name, work_description, work_order_no,
                       agreement_amount, bill_amount, period, district, tehsil, village, office,
                       income_tax, labour_cess, security_deposit, other_deductions,
                       total_deductions, net_amount):
    """Display the generated Hindi bill"""
    
    st.success("✅ Hindi Bill generated successfully / हिंदी बिल सफलतापूर्वक तैयार किया गया!")
    
    st.markdown("---")
    st.markdown("## 📋 हिंदी बिल / HINDI BILL")
    
    # Header
    st.markdown(f"""
    <div style="text-align: center; border: 2px solid #004E89; padding: 20px; margin: 10px 0; background-color: #F8F9FA;">
        <h2 style="color: #004E89; margin: 0;">राजस्थान सरकार</h2>
        <h3 style="color: #FF6B35; margin: 5px 0;">लोक निर्माण विभाग</h3>
        <h4 style="color: #004E89; margin: 5px 0;">{office}</h4>
        <hr style="border: 1px solid #004E89; margin: 10px 0;">
        <h3 style="color: #004E89; margin: 10px 0;">बिल संख्या: {bill_no}</h3>
        <p style="margin: 5px 0;">दिनांक: {bill_date.strftime('%d/%m/%Y')}</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Bill details
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown(f"""
        **ठेकेदार का नाम:** {contractor_name}  
        **कार्य आदेश संख्या:** {work_order_no}  
        **समझौता राशि:** ₹{agreement_amount:,.2f}  
        **अवधि:** {period}  
        **जिला:** {district}
        """)
    
    with col2:
        st.markdown(f"""
        **तहसील:** {tehsil}  
        **गांव:** {village}  
        **बिल राशि:** ₹{bill_amount:,.2f}  
        **कुल कटौती:** ₹{total_deductions:,.2f}  
        **शुद्ध देय राशि:** ₹{net_amount:,.2f}
        """)
    
    # Work description
    st.markdown("**कार्य विवरण:**")
    st.write(work_description)
    
    # Deductions table
    if total_deductions > 0:
        st.markdown("### कटौतियों का विवरण")
        
        deductions_data = []
        if income_tax > 0:
            deductions_data.append({"कटौती का प्रकार": "आयकर", "राशि (₹)": f"{income_tax:,.2f}"})
        if labour_cess > 0:
            deductions_data.append({"कटौती का प्रकार": "श्रमिक उपकर", "राशि (₹)": f"{labour_cess:,.2f}"})
        if security_deposit > 0:
            deductions_data.append({"कटौती का प्रकार": "जमानत राशि", "राशि (₹)": f"{security_deposit:,.2f}"})
        if other_deductions > 0:
            deductions_data.append({"कटौती का प्रकार": "अन्य कटौतियां", "राशि (₹)": f"{other_deductions:,.2f}"})
        
        df_deductions = pd.DataFrame(deductions_data)
        st.table(df_deductions)
    
    # Summary table
    st.markdown("### राशि का सारांश")
    
    summary_data = {
        'विवरण': ['बिल राशि', 'कुल कटौती', 'शुद्ध देय राशि'],
        'राशि (₹)': [f"{bill_amount:,.2f}", f"{total_deductions:,.2f}", f"{net_amount:,.2f}"]
    }
    
    df_summary = pd.DataFrame(summary_data)
    st.table(df_summary)
    
    # Signatures section
    st.markdown("---")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("**ठेकेदार के हस्ताक्षर**")
        st.write("_" * 20)
    
    with col2:
        st.markdown("**सहायक अभियंता**")
        st.write("_" * 20)
    
    with col3:
        st.markdown("**कार्यपालन अभियंता**")
        st.write("_" * 20)
    
    # Generate downloadable version
    generate_hindi_bill_download(bill_no, bill_date, contractor_name, net_amount)

def generate_payment_order():
    """Generate payment order in Hindi"""
    
    st.markdown("#### 💰 Payment Order Generation / भुगतान आदेश निर्माण")
    
    with st.form("payment_order_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            order_no = st.text_input("Order Number / आदेश संख्या*")
            order_date = st.date_input("Order Date / आदेश दिनांक*", value=date.today())
            payee_name = st.text_input("Payee Name / प्राप्तकर्ता का नाम*")
        
        with col2:
            amount = st.number_input("Amount / राशि (₹)*", min_value=0.0, format="%.2f")
            reference_bill = st.text_input("Reference Bill / संदर्भ बिल")
            bank_details = st.text_input("Bank Details / बैंक विवरण")
        
        purpose = st.text_area("Purpose / प्रयोजन*", height=100)
        
        submitted = st.form_submit_button("Generate Payment Order / भुगतान आदेश तैयार करें")
    
    if submitted and all([order_no, payee_name, amount > 0, purpose]):
        display_payment_order(order_no, order_date, payee_name, amount, reference_bill, bank_details, purpose)

def display_payment_order(order_no, order_date, payee_name, amount, reference_bill, bank_details, purpose):
    """Display payment order in Hindi"""
    
    st.success("✅ Payment Order generated / भुगतान आदेश तैयार किया गया!")
    
    st.markdown("---")
    st.markdown("## 💰 भुगतान आदेश / PAYMENT ORDER")
    
    # Header
    st.markdown(f"""
    <div style="text-align: center; border: 2px solid #004E89; padding: 20px; margin: 10px 0; background-color: #F8F9FA;">
        <h2 style="color: #004E89; margin: 0;">राजस्थान सरकार</h2>
        <h3 style="color: #FF6B35; margin: 5px 0;">लोक निर्माण विभाग</h3>
        <h4 style="color: #004E89; margin: 5px 0;">उदयपुर</h4>
        <hr style="border: 1px solid #004E89; margin: 10px 0;">
        <h3 style="color: #004E89; margin: 10px 0;">भुगतान आदेश संख्या: {order_no}</h3>
        <p style="margin: 5px 0;">दिनांक: {order_date.strftime('%d/%m/%Y')}</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Payment details
    st.markdown(f"""
    **प्राप्तकर्ता का नाम:** {payee_name}  
    **भुगतान राशि:** ₹{amount:,.2f}  
    **संदर्भ बिल:** {reference_bill}  
    **बैंक विवरण:** {bank_details}  
    
    **प्रयोजन:**  
    {purpose}
    """)

def generate_work_order():
    """Generate work order in Hindi"""
    
    st.markdown("#### 🔨 Work Order Generation / कार्य आदेश निर्माण")
    
    with st.form("work_order_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            wo_no = st.text_input("Work Order No. / कार्य आदेश संख्या*")
            wo_date = st.date_input("Work Order Date / कार्य आदेश दिनांक*", value=date.today())
            contractor = st.text_input("Contractor Name / ठेकेदार का नाम*")
        
        with col2:
            work_value = st.number_input("Work Value / कार्य मूल्य (₹)*", min_value=0.0, format="%.2f")
            completion_period = st.number_input("Completion Period (Days) / पूर्णता अवधि (दिन)*", min_value=1)
            start_date = st.date_input("Start Date / प्रारंभ दिनांक*")
        
        work_details = st.text_area("Work Details / कार्य विवरण*", height=150)
        
        submitted = st.form_submit_button("Generate Work Order / कार्य आदेश तैयार करें")
    
    if submitted and all([wo_no, contractor, work_value > 0, work_details]):
        display_work_order(wo_no, wo_date, contractor, work_value, completion_period, start_date, work_details)

def display_work_order(wo_no, wo_date, contractor, work_value, completion_period, start_date, work_details):
    """Display work order in Hindi"""
    
    st.success("✅ Work Order generated / कार्य आदेश तैयार किया गया!")
    
    st.markdown("---")
    st.markdown("## 🔨 कार्य आदेश / WORK ORDER")
    
    # Header
    st.markdown(f"""
    <div style="text-align: center; border: 2px solid #004E89; padding: 20px; margin: 10px 0; background-color: #F8F9FA;">
        <h2 style="color: #004E89; margin: 0;">राजस्थान सरकार</h2>
        <h3 style="color: #FF6B35; margin: 5px 0;">लोक निर्माण विभाग</h3>
        <h4 style="color: #004E89; margin: 5px 0;">उदयपुर</h4>
        <hr style="border: 1px solid #004E89; margin: 10px 0;">
        <h3 style="color: #004E89; margin: 10px 0;">कार्य आदेश संख्या: {wo_no}</h3>
        <p style="margin: 5px 0;">दिनांक: {wo_date.strftime('%d/%m/%Y')}</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Work order details
    st.markdown(f"""
    **ठेकेदार का नाम:** {contractor}  
    **कार्य मूल्य:** ₹{work_value:,.2f}  
    **पूर्णता अवधि:** {completion_period} दिन  
    **प्रारंभ दिनांक:** {start_date.strftime('%d/%m/%Y')}  
    
    **कार्य विवरण:**  
    {work_details}
    """)

def generate_completion_certificate():
    """Generate completion certificate in Hindi"""
    
    st.markdown("#### ✅ Completion Certificate / पूर्णता प्रमाणपत्र")
    
    with st.form("completion_cert_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            cert_no = st.text_input("Certificate No. / प्रमाणपत्र संख्या*")
            cert_date = st.date_input("Certificate Date / प्रमाणपत्र दिनांक*", value=date.today())
            contractor = st.text_input("Contractor Name / ठेकेदार का नाम*")
        
        with col2:
            work_order_ref = st.text_input("Work Order Reference / कार्य आदेश संदर्भ*")
            completion_date = st.date_input("Actual Completion Date / वास्तविक पूर्णता दिनांक*")
            final_amount = st.number_input("Final Amount / अंतिम राशि (₹)*", min_value=0.0, format="%.2f")
        
        work_summary = st.text_area("Work Summary / कार्य सारांश*", height=100)
        
        submitted = st.form_submit_button("Generate Certificate / प्रमाणपत्र तैयार करें")
    
    if submitted and all([cert_no, contractor, work_order_ref, work_summary]):
        display_completion_certificate(cert_no, cert_date, contractor, work_order_ref, completion_date, final_amount, work_summary)

def display_completion_certificate(cert_no, cert_date, contractor, work_order_ref, completion_date, final_amount, work_summary):
    """Display completion certificate in Hindi"""
    
    st.success("✅ Completion Certificate generated / पूर्णता प्रमाणपत्र तैयार किया गया!")
    
    st.markdown("---")
    st.markdown("## ✅ पूर्णता प्रमाणपत्र / COMPLETION CERTIFICATE")
    
    # Header
    st.markdown(f"""
    <div style="text-align: center; border: 2px solid #004E89; padding: 20px; margin: 10px 0; background-color: #F8F9FA;">
        <h2 style="color: #004E89; margin: 0;">राजस्थान सरकार</h2>
        <h3 style="color: #FF6B35; margin: 5px 0;">लोक निर्माण विभाग</h3>
        <h4 style="color: #004E89; margin: 5px 0;">उदयपुर</h4>
        <hr style="border: 1px solid #004E89; margin: 10px 0;">
        <h3 style="color: #004E89; margin: 10px 0;">पूर्णता प्रमाणपत्र संख्या: {cert_no}</h3>
        <p style="margin: 5px 0;">दिनांक: {cert_date.strftime('%d/%m/%Y')}</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Certificate details
    st.markdown(f"""
    **ठेकेदार का नाम:** {contractor}  
    **कार्य आदेश संदर्भ:** {work_order_ref}  
    **वास्तविक पूर्णता दिनांक:** {completion_date.strftime('%d/%m/%Y')}  
    **अंतिम राशि:** ₹{final_amount:,.2f}  
    
    **कार्य सारांश:**  
    {work_summary}
    
    **प्रमाणन:**  
    यह प्रमाणित किया जाता है कि उपरोक्त वर्णित कार्य संतोषजनक रूप से पूर्ण किया गया है।
    """)

def generate_hindi_bill_download(bill_no, bill_date, contractor_name, net_amount):
    """Generate downloadable Hindi bill data"""
    
    bill_text = f"""
हिंदी बिल रिपोर्ट
==================

बिल संख्या: {bill_no}
दिनांक: {bill_date.strftime('%d/%m/%Y')}
ठेकेदार का नाम: {contractor_name}
शुद्ध देय राशि: ₹{net_amount:,.2f}

तैयार किया गया: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
PWD Tools - Hindi Bill Generator
"""
    
    st.download_button(
        label="📥 Download Hindi Bill Report / हिंदी बिल रिपोर्ट डाउनलोड करें",
        data=bill_text,
        file_name=f"hindi_bill_{bill_no}_{datetime.now().strftime('%Y%m%d')}.txt",
        mime="text/plain",
        use_container_width=True
    )

if __name__ == "__main__":
    main()
