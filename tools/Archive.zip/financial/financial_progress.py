"""
Financial Progress Tool
Track and analyze financial progress of projects
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, date

def main():
    """Main function for Financial Progress tool"""
    st.markdown("### 📈 Financial Progress Tracker")
    st.markdown("Track and analyze financial progress of PWD projects")
    
    # Project setup
    with st.form("project_setup"):
        col1, col2 = st.columns(2)
        
        with col1:
            project_name = st.text_input("Project Name*", placeholder="Enter project name")
            contract_value = st.number_input("Contract Value (₹)*", min_value=0.0, format="%.2f")
            start_date = st.date_input("Project Start Date*")
        
        with col2:
            project_code = st.text_input("Project Code", placeholder="Project ID/Code")
            completion_date = st.date_input("Expected Completion Date*")
            contractor_name = st.text_input("Contractor Name", placeholder="Contractor name")
        
        setup_submitted = st.form_submit_button("Setup Project Tracking")
    
    if setup_submitted and project_name and contract_value > 0:
        st.session_state.project_setup = {
            'name': project_name,
            'code': project_code,
            'value': contract_value,
            'start_date': start_date,
            'completion_date': completion_date,
            'contractor': contractor_name
        }
        st.success("✅ Project setup completed!")
    
    # Progress tracking
    if 'project_setup' in st.session_state:
        track_financial_progress()

def track_financial_progress():
    """Track financial progress of the project"""
    
    project = st.session_state.project_setup
    
    st.markdown("---")
    st.markdown(f"## 📊 Financial Progress - {project['name']}")
    
    # Add progress entry
    with st.expander("➕ Add Progress Entry", expanded=False):
        with st.form("progress_entry"):
            col1, col2, col3 = st.columns(3)
            
            with col1:
                entry_date = st.date_input("Entry Date", value=date.today())
                bill_number = st.text_input("Bill Number", placeholder="Bill/Invoice No.")
            
            with col2:
                work_done_amount = st.number_input("Work Done Amount (₹)", min_value=0.0, format="%.2f")
                payment_amount = st.number_input("Payment Amount (₹)", min_value=0.0, format="%.2f")
            
            with col3:
                work_description = st.text_area("Work Description", height=100)
            
            entry_submitted = st.form_submit_button("Add Entry")
    
    if entry_submitted and work_done_amount > 0:
        add_progress_entry(entry_date, bill_number, work_done_amount, payment_amount, work_description)
    
    # Display progress data
    display_financial_progress(project)

def add_progress_entry(entry_date, bill_number, work_done_amount, payment_amount, work_description):
    """Add a new progress entry"""
    
    if 'progress_entries' not in st.session_state:
        st.session_state.progress_entries = []
    
    entry = {
        'date': entry_date,
        'bill_number': bill_number,
        'work_done_amount': work_done_amount,
        'payment_amount': payment_amount,
        'description': work_description,
        'cumulative_work': sum([e['work_done_amount'] for e in st.session_state.progress_entries]) + work_done_amount,
        'cumulative_payment': sum([e['payment_amount'] for e in st.session_state.progress_entries]) + payment_amount
    }
    
    st.session_state.progress_entries.append(entry)
    st.success("✅ Progress entry added successfully!")
    st.rerun()

def display_financial_progress(project):
    """Display financial progress charts and tables"""
    
    if 'progress_entries' not in st.session_state or not st.session_state.progress_entries:
        st.info("📝 No progress entries added yet. Add your first entry above to start tracking.")
        return
    
    entries = st.session_state.progress_entries
    df = pd.DataFrame(entries)
    
    # Overview metrics
    col1, col2, col3, col4 = st.columns(4)
    
    contract_value = project['value']
    total_work_done = df['work_done_amount'].sum()
    total_payments = df['payment_amount'].sum()
    progress_percentage = (total_work_done / contract_value * 100) if contract_value > 0 else 0
    
    with col1:
        st.metric("Contract Value", f"₹{contract_value:,.2f}")
    with col2:
        st.metric("Work Done", f"₹{total_work_done:,.2f}", f"{progress_percentage:.1f}%")
    with col3:
        st.metric("Payments Received", f"₹{total_payments:,.2f}")
    with col4:
        pending_payment = total_work_done - total_payments
        st.metric("Pending Payment", f"₹{pending_payment:,.2f}")
    
    # Progress chart
    st.markdown("### 📊 Progress Visualization")
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=df['date'], 
        y=df['cumulative_work'],
        mode='lines+markers',
        name='Cumulative Work Done',
        line=dict(color='#1f77b4', width=3)
    ))
    
    fig.add_trace(go.Scatter(
        x=df['date'], 
        y=df['cumulative_payment'],
        mode='lines+markers',
        name='Cumulative Payment',
        line=dict(color='#ff7f0e', width=3)
    ))
    
    fig.update_layout(
        title='Financial Progress Over Time',
        xaxis_title='Date',
        yaxis_title='Amount (₹)',
        hovermode='x unified'
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Progress table
    st.markdown("### 📋 Progress Entries")
    
    display_df = df.copy()
    display_df['date'] = pd.to_datetime(display_df['date']).dt.strftime('%Y-%m-%d')
    display_df['work_done_amount'] = display_df['work_done_amount'].apply(lambda x: f"₹{x:,.2f}")
    display_df['payment_amount'] = display_df['payment_amount'].apply(lambda x: f"₹{x:,.2f}")
    display_df['cumulative_work'] = display_df['cumulative_work'].apply(lambda x: f"₹{x:,.2f}")
    display_df['cumulative_payment'] = display_df['cumulative_payment'].apply(lambda x: f"₹{x:,.2f}")
    
    st.dataframe(
        display_df[['date', 'bill_number', 'work_done_amount', 'payment_amount', 
                   'cumulative_work', 'cumulative_payment', 'description']],
        use_container_width=True
    )
