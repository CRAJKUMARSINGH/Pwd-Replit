"""
Stamp Duty Calculator Tool
Calculate stamp duty for various PWD documents and agreements
"""

import streamlit as st
import pandas as pd
from datetime import datetime, date

def main():
    """Main function for Stamp Duty Calculator tool"""
    st.markdown("### 📄 Stamp Duty Calculator")
    st.markdown("Calculate stamp duty for PWD documents, agreements, and contracts")
    
    # Document type selection
    doc_type = st.selectbox(
        "Select Document Type:",
        [
            "Select Document Type",
            "Work Contract Agreement",
            "Supply Contract Agreement", 
            "Lease Agreement",
            "Indemnity Bond",
            "Performance Guarantee",
            "Affidavit",
            "Power of Attorney",
            "Partnership Deed",
            "Sale Deed",
            "Other Legal Document"
        ]
    )
    
    if doc_type != "Select Document Type":
        calculate_stamp_duty_for_document(doc_type)
    else:
        st.info("Please select a document type to calculate stamp duty")

def calculate_stamp_duty_for_document(doc_type):
    """Calculate stamp duty based on document type"""
    
    st.markdown(f"#### Calculating Stamp Duty for: {doc_type}")
    
    with st.form(f"stamp_duty_form_{doc_type.replace(' ', '_')}"):
        # Common fields
        col1, col2 = st.columns(2)
        
        with col1:
            document_date = st.date_input("Document Date", value=date.today())
            execution_place = st.selectbox("Place of Execution", [
                "Rajasthan", "Delhi", "Maharashtra", "Gujarat", "Punjab", "Haryana", "Other"
            ])
        
        with col2:
            document_value = st.number_input("Document Value/Contract Amount (₹)", min_value=0.0, format="%.2f")
            urgency = st.checkbox("Urgent Processing Required")
        
        # Document-specific fields
        if doc_type in ["Work Contract Agreement", "Supply Contract Agreement"]:
            contract_duration = st.number_input("Contract Duration (Months)", min_value=1, value=12)
            work_description = st.text_area("Work/Supply Description", height=80)
            
        elif doc_type == "Lease Agreement":
            lease_period = st.number_input("Lease Period (Years)", min_value=1, value=1)
            annual_rent = st.number_input("Annual Rent (₹)", min_value=0.0, format="%.2f")
            security_deposit = st.number_input("Security Deposit (₹)", min_value=0.0, format="%.2f")
            
        elif doc_type in ["Indemnity Bond", "Performance Guarantee"]:
            guarantee_amount = st.number_input("Guarantee Amount (₹)", min_value=0.0, format="%.2f")
            validity_period = st.number_input("Validity Period (Months)", min_value=1, value=12)
            
        elif doc_type == "Sale Deed":
            property_type = st.selectbox("Property Type", ["Residential", "Commercial", "Industrial", "Agricultural"])
            property_area = st.number_input("Property Area (Sq. Ft.)", min_value=0.0)
            market_value = st.number_input("Market Value (₹)", min_value=0.0, format="%.2f")
        
        # Party details
        st.markdown("#### Party Details")
        col3, col4 = st.columns(2)
        
        with col3:
            first_party = st.text_input("First Party Name")
            first_party_address = st.text_area("First Party Address", height=60)
        
        with col4:
            second_party = st.text_input("Second Party Name")
            second_party_address = st.text_area("Second Party Address", height=60)
        
        submitted = st.form_submit_button("Calculate Stamp Duty", use_container_width=True)
    
    if submitted:
        if document_value <= 0:
            st.error("Please enter a valid document value")
            return
        
        # Calculate stamp duty based on document type and state
        stamp_duty_amount, calculation_details = calculate_stamp_duty(
            doc_type, document_value, execution_place, locals()
        )
        
        display_stamp_duty_results(
            doc_type, document_value, stamp_duty_amount, calculation_details,
            execution_place, document_date, first_party, second_party
        )

def calculate_stamp_duty(doc_type, document_value, execution_place, form_data):
    """Calculate stamp duty amount based on document type and state"""
    
    # Rajasthan stamp duty rates (as example - adjust based on actual rates)
    rajasthan_rates = {
        "Work Contract Agreement": {"rate": 0.1, "min_amount": 100, "max_amount": 25000},
        "Supply Contract Agreement": {"rate": 0.1, "min_amount": 100, "max_amount": 25000},
        "Lease Agreement": {"rate": 2.0, "min_amount": 100, "max_amount": None},
        "Indemnity Bond": {"rate": 0.1, "min_amount": 100, "max_amount": 10000},
        "Performance Guarantee": {"rate": 0.1, "min_amount": 100, "max_amount": 10000},
        "Affidavit": {"rate": 0, "min_amount": 20, "max_amount": 20},
        "Power of Attorney": {"rate": 0, "min_amount": 100, "max_amount": 100},
        "Partnership Deed": {"rate": 0.1, "min_amount": 500, "max_amount": None},
        "Sale Deed": {"rate": 5.0, "min_amount": 100, "max_amount": None},
        "Other Legal Document": {"rate": 0.1, "min_amount": 100, "max_amount": 1000}
    }
    
    # Get rate for the document type
    if execution_place == "Rajasthan":
        rate_info = rajasthan_rates.get(doc_type, {"rate": 0.1, "min_amount": 100, "max_amount": 1000})
    else:
        # Default rates for other states
        rate_info = {"rate": 0.1, "min_amount": 100, "max_amount": 1000}
    
    # Calculate stamp duty
    if doc_type == "Lease Agreement" and "annual_rent" in form_data:
        # For lease agreements, calculate based on annual rent
        calculated_amount = (form_data["annual_rent"] * rate_info["rate"]) / 100
    elif doc_type in ["Indemnity Bond", "Performance Guarantee"] and "guarantee_amount" in form_data:
        # For bonds and guarantees, calculate based on guarantee amount
        calculated_amount = (form_data["guarantee_amount"] * rate_info["rate"]) / 100
    elif doc_type == "Sale Deed" and "market_value" in form_data:
        # For sale deeds, calculate based on market value
        calculated_amount = (form_data["market_value"] * rate_info["rate"]) / 100
    else:
        # For other documents, calculate based on document value
        calculated_amount = (document_value * rate_info["rate"]) / 100
    
    # Apply minimum and maximum limits
    if rate_info["min_amount"]:
        calculated_amount = max(calculated_amount, rate_info["min_amount"])
    
    if rate_info["max_amount"]:
        calculated_amount = min(calculated_amount, rate_info["max_amount"])
    
    # Prepare calculation details
    calculation_details = {
        "rate_percent": rate_info["rate"],
        "min_amount": rate_info["min_amount"],
        "max_amount": rate_info["max_amount"],
        "calculation_base": document_value,
        "state": execution_place
    }
    
    return calculated_amount, calculation_details

def display_stamp_duty_results(doc_type, document_value, stamp_duty_amount, calculation_details,
                              execution_place, document_date, first_party, second_party):
    """Display stamp duty calculation results"""
    
    st.success("✅ Stamp duty calculated successfully!")
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Document Value", f"₹{document_value:,.2f}")
    
    with col2:
        st.metric("Stamp Duty Rate", f"{calculation_details['rate_percent']}%")
    
    with col3:
        st.metric("Stamp Duty Amount", f"₹{stamp_duty_amount:,.2f}")
    
    with col4:
        st.metric("Total Cost", f"₹{document_value + stamp_duty_amount:,.2f}")
    
    # Detailed calculation
    st.markdown("---")
    st.markdown("## 📄 STAMP DUTY CALCULATION CERTIFICATE")
    
    # Document information
    info_col1, info_col2 = st.columns(2)
    
    with info_col1:
        st.markdown(f"""
        **Document Type:** {doc_type}  
        **Document Date:** {document_date.strftime('%d/%m/%Y')}  
        **Place of Execution:** {execution_place}  
        **Document Value:** ₹{document_value:,.2f}
        """)
    
    with info_col2:
        st.markdown(f"""
        **First Party:** {first_party}  
        **Second Party:** {second_party}  
        **Stamp Duty Rate:** {calculation_details['rate_percent']}%  
        **Stamp Duty Amount:** ₹{stamp_duty_amount:,.2f}
        """)
    
    # Calculation breakdown
    st.markdown("### Calculation Breakdown")
    
    calc_data = {
        'Component': [
            'Document Value/Base Amount',
            'Stamp Duty Rate',
            'Calculated Amount',
            'Minimum Amount Limit',
            'Maximum Amount Limit',
            'Final Stamp Duty Amount'
        ],
        'Value': [
            f"₹{document_value:,.2f}",
            f"{calculation_details['rate_percent']}%",
            f"₹{(document_value * calculation_details['rate_percent']) / 100:,.2f}",
            f"₹{calculation_details['min_amount']:,.2f}" if calculation_details['min_amount'] else "N/A",
            f"₹{calculation_details['max_amount']:,.2f}" if calculation_details['max_amount'] else "No Limit",
            f"₹{stamp_duty_amount:,.2f}"
        ]
    }
    
    df_calc = pd.DataFrame(calc_data)
    st.table(df_calc)
    
    # Additional information based on document type
    display_document_specific_info(doc_type)
    
    # Payment instructions
    st.markdown("### Payment Instructions")
    st.info("""
    **Stamp Duty Payment Options:**
    - Online payment through state portal
    - Physical stamp paper purchase
    - E-stamping facility
    - Franking at authorized centers
    
    **Required Documents:**
    - Original agreement/document
    - Identity proof of parties
    - Address proof
    - PAN card (for high-value transactions)
    """)
    
    # Generate reports
    generate_stamp_duty_reports(
        doc_type, document_value, stamp_duty_amount, calculation_details,
        execution_place, document_date, first_party, second_party
    )

def display_document_specific_info(doc_type):
    """Display document-specific information and requirements"""
    
    if doc_type in ["Work Contract Agreement", "Supply Contract Agreement"]:
        st.markdown("### Contract Agreement Requirements")
        st.info("""
        **Additional Requirements for Contract Agreements:**
        - Registration may be required for contracts above ₹100
        - Include detailed scope of work
        - Specify terms and conditions clearly
        - Add penalty clauses for delays
        - Include force majeure provisions
        """)
    
    elif doc_type == "Lease Agreement":
        st.markdown("### Lease Agreement Requirements")
        st.info("""
        **Additional Requirements for Lease Agreements:**
        - Registration mandatory for leases above 11 months
        - Include maintenance responsibilities
        - Specify rent escalation terms
        - Add security deposit terms
        - Include termination clauses
        """)
    
    elif doc_type in ["Indemnity Bond", "Performance Guarantee"]:
        st.markdown("### Bond/Guarantee Requirements")
        st.info("""
        **Additional Requirements for Bonds/Guarantees:**
        - Bank guarantee format to be approved
        - Include claim procedure
        - Specify validity period clearly
        - Add auto-renewal clauses if required
        - Include jurisdiction clauses
        """)

def generate_stamp_duty_reports(doc_type, document_value, stamp_duty_amount, calculation_details,
                               execution_place, document_date, first_party, second_party):
    """Generate downloadable stamp duty reports"""
    
    # Certificate data
    certificate_data = {
        'Field': [
            'Document Type', 'Document Date', 'Place of Execution', 'Document Value',
            'First Party', 'Second Party', 'Stamp Duty Rate', 'Stamp Duty Amount'
        ],
        'Details': [
            doc_type, document_date.strftime('%d/%m/%Y'), execution_place, f"₹{document_value:,.2f}",
            first_party, second_party, f"{calculation_details['rate_percent']}%", f"₹{stamp_duty_amount:,.2f}"
        ]
    }
    
    df_certificate = pd.DataFrame(certificate_data)
    csv_certificate = df_certificate.to_csv(index=False)
    
    # Download button
    st.download_button(
        label="📥 Download Stamp Duty Certificate (CSV)",
        data=csv_certificate,
        file_name=f"stamp_duty_certificate_{datetime.now().strftime('%Y%m%d')}.csv",
        mime="text/csv",
        use_container_width=True
    )
    
    # Detailed calculation report
    detailed_report = f"""
STAMP DUTY CALCULATION CERTIFICATE
==================================

Document Details:
- Type: {doc_type}
- Date: {document_date.strftime('%d/%m/%Y')}
- Place of Execution: {execution_place}
- Value: ₹{document_value:,.2f}

Parties:
- First Party: {first_party}
- Second Party: {second_party}

Calculation:
- Base Amount: ₹{document_value:,.2f}
- Stamp Duty Rate: {calculation_details['rate_percent']}%
- Minimum Amount: ₹{calculation_details['min_amount']:,.2f}
- Maximum Amount: {f"₹{calculation_details['max_amount']:,.2f}" if calculation_details['max_amount'] else "No Limit"}
- Final Stamp Duty: ₹{stamp_duty_amount:,.2f}

Total Document Cost: ₹{document_value + stamp_duty_amount:,.2f}

Generated on: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
PWD Tools - Stamp Duty Calculator
"""
    
    st.download_button(
        label="📄 Download Detailed Certificate (TXT)",
        data=detailed_report,
        file_name=f"stamp_duty_detailed_{datetime.now().strftime('%Y%m%d')}.txt",
        mime="text/plain",
        use_container_width=True
    )

if __name__ == "__main__":
    main()
