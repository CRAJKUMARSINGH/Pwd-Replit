"""
Delay Calculator Tool
Calculate project delays and penalties
"""

import streamlit as st
import pandas as pd
from datetime import datetime, date, timedelta
import plotly.express as px
import plotly.graph_objects as go

def main():
    """Main function for Delay Calculator tool"""
    st.markdown("### ⏰ Delay Calculator")
    st.markdown("Calculate project delays, analyze causes, and compute penalties")
    
    # Project information
    with st.form("delay_calculation_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            project_name = st.text_input("Project Name*", placeholder="Enter project name")
            contract_start_date = st.date_input("Contract Start Date*")
            contract_end_date = st.date_input("Contract End Date*")
            contract_value = st.number_input("Contract Value (₹)*", min_value=0.0, format="%.2f")
        
        with col2:
            contractor_name = st.text_input("Contractor Name", placeholder="Contractor name")
            actual_start_date = st.date_input("Actual Start Date", value=None)
            actual_end_date = st.date_input("Actual/Expected End Date", value=date.today())
            penalty_rate = st.number_input("Penalty Rate (% per day)*", min_value=0.0, max_value=1.0, value=0.05, format="%.3f")
        
        # Additional parameters
        st.markdown("#### Additional Parameters")
        col3, col4 = st.columns(2)
        
        with col3:
            weather_delays = st.number_input("Weather Delays (days)", min_value=0, value=0)
            material_delays = st.number_input("Material Supply Delays (days)", min_value=0, value=0)
        
        with col4:
            approval_delays = st.number_input("Approval Delays (days)", min_value=0, value=0)
            other_delays = st.number_input("Other Delays (days)", min_value=0, value=0)
        
        delay_reason = st.text_area("Primary Delay Reasons", height=100, placeholder="Describe main reasons for delay...")
        
        submitted = st.form_submit_button("Calculate Delays", use_container_width=True)
    
    if submitted:
        if not all([project_name, contract_start_date, contract_end_date, contract_value > 0]):
            st.error("Please fill all required fields marked with *")
            return
        
        calculate_project_delays(
            project_name, contractor_name, contract_start_date, contract_end_date,
            actual_start_date, actual_end_date, contract_value, penalty_rate,
            weather_delays, material_delays, approval_delays, other_delays, delay_reason
        )

def calculate_project_delays(project_name, contractor_name, contract_start_date, contract_end_date,
                           actual_start_date, actual_end_date, contract_value, penalty_rate,
                           weather_delays, material_delays, approval_delays, other_delays, delay_reason):
    """Calculate and analyze project delays"""
    
    # Calculate contract duration
    contract_duration = (contract_end_date - contract_start_date).days
    
    # Calculate actual duration (if project started)
    if actual_start_date:
        actual_duration = (actual_end_date - actual_start_date).days
        start_delay = (actual_start_date - contract_start_date).days if actual_start_date > contract_start_date else 0
    else:
        actual_duration = None
        start_delay = 0
    
    # Calculate completion delay
    completion_delay = (actual_end_date - contract_end_date).days if actual_end_date > contract_end_date else 0
    
    # Calculate total excusable delays
    total_excusable_delays = weather_delays + material_delays + approval_delays + other_delays
    
    # Calculate net delay (after accounting for excusable delays)
    net_delay = max(0, completion_delay - total_excusable_delays)
    
    # Calculate penalty
    daily_penalty_amount = (contract_value * penalty_rate) / 100
    total_penalty = net_delay * daily_penalty_amount
    
    # Display results
    st.success("✅ Delay analysis completed successfully!")
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Contract Duration", f"{contract_duration} days")
    
    with col2:
        st.metric("Completion Delay", f"{completion_delay} days", delta=f"{completion_delay} days" if completion_delay > 0 else None)
    
    with col3:
        st.metric("Net Delay", f"{net_delay} days", delta=f"-{total_excusable_delays} (excused)" if total_excusable_delays > 0 else None)
    
    with col4:
        st.metric("Total Penalty", f"₹{total_penalty:,.2f}", delta=f"₹{daily_penalty_amount:,.2f}/day")
    
    # Detailed analysis
    st.markdown("---")
    st.markdown("## ⏰ DELAY ANALYSIS REPORT")
    
    # Project information
    info_col1, info_col2 = st.columns(2)
    
    with info_col1:
        st.markdown(f"""
        **Project Name:** {project_name}  
        **Contractor:** {contractor_name}  
        **Contract Value:** ₹{contract_value:,.2f}  
        **Contract Duration:** {contract_duration} days  
        **Penalty Rate:** {penalty_rate}% per day
        """)
    
    with info_col2:
        st.markdown(f"""
        **Contract Start:** {contract_start_date.strftime('%d/%m/%Y')}  
        **Contract End:** {contract_end_date.strftime('%d/%m/%Y')}  
        **Actual End:** {actual_end_date.strftime('%d/%m/%Y')}  
        **Completion Delay:** {completion_delay} days  
        **Net Delay:** {net_delay} days
        """)
    
    # Timeline visualization
    create_delay_timeline(contract_start_date, contract_end_date, actual_start_date, actual_end_date)
    
    # Delay breakdown
    if total_excusable_delays > 0:
        st.markdown("### Delay Breakdown Analysis")
        
        delay_categories = ['Weather Delays', 'Material Delays', 'Approval Delays', 'Other Delays', 'Net Penalty Delay']
        delay_values = [weather_delays, material_delays, approval_delays, other_delays, net_delay]
        delay_colors = ['#FFA07A', '#98D8C8', '#F7DC6F', '#BB8FCE', '#FF6B6B']
        
        # Create pie chart for delay breakdown
        fig_pie = go.Figure(data=[go.Pie(
            labels=delay_categories,
            values=delay_values,
            marker_colors=delay_colors,
            textinfo='label+percent+value',
            texttemplate='%{label}<br>%{value} days<br>(%{percent})'
        )])
        
        fig_pie.update_layout(
            title="Delay Breakdown by Category",
            height=400
        )
        
        st.plotly_chart(fig_pie, use_container_width=True)
    
    # Delay impact table
    st.markdown("### Delay Impact Analysis")
    
    delay_impact_data = {
        'Delay Category': ['Contract Completion Delay', 'Excusable Delays', 'Net Penalty Delay'],
        'Days': [completion_delay, total_excusable_delays, net_delay],
        'Financial Impact': ['N/A', 'No Penalty', f"₹{total_penalty:,.2f}"],
        'Status': ['Total Delay', 'Excused', 'Penalizable']
    }
    
    df_impact = pd.DataFrame(delay_impact_data)
    st.table(df_impact)
    
    # Detailed delay analysis
    if total_excusable_delays > 0:
        st.markdown("### Detailed Delay Analysis")
        
        detailed_delays = []
        if weather_delays > 0:
            detailed_delays.append({"Category": "Weather Delays", "Days": weather_delays, "Impact": "Excusable", "Penalty": "₹0"})
        if material_delays > 0:
            detailed_delays.append({"Category": "Material Supply Delays", "Days": material_delays, "Impact": "Excusable", "Penalty": "₹0"})
        if approval_delays > 0:
            detailed_delays.append({"Category": "Approval Delays", "Days": approval_delays, "Impact": "Excusable", "Penalty": "₹0"})
        if other_delays > 0:
            detailed_delays.append({"Category": "Other Delays", "Days": other_delays, "Impact": "Excusable", "Penalty": "₹0"})
        if net_delay > 0:
            detailed_delays.append({"Category": "Net Contractor Delay", "Days": net_delay, "Impact": "Penalizable", "Penalty": f"₹{total_penalty:,.2f}"})
        
        if detailed_delays:
            df_detailed = pd.DataFrame(detailed_delays)
            st.table(df_detailed)
    
    # Penalty calculation details
    if net_delay > 0:
        st.markdown("### Penalty Calculation")
        
        penalty_calc_data = {
            'Component': [
                'Contract Value',
                'Penalty Rate (per day)',
                'Daily Penalty Amount',
                'Net Penalty Days',
                'Total Penalty Amount'
            ],
            'Value': [
                f"₹{contract_value:,.2f}",
                f"{penalty_rate}%",
                f"₹{daily_penalty_amount:,.2f}",
                f"{net_delay} days",
                f"₹{total_penalty:,.2f}"
            ],
            'Calculation': [
                "Contract Value",
                "As per contract terms",
                f"₹{contract_value:,.2f} × {penalty_rate}% ÷ 100",
                "Total delay - Excusable delays",
                f"₹{daily_penalty_amount:,.2f} × {net_delay} days"
            ]
        }
        
        df_penalty = pd.DataFrame(penalty_calc_data)
        st.table(df_penalty)
    
    # Delay reasons
    if delay_reason:
        st.markdown("### Primary Delay Reasons")
        st.write(delay_reason)
    
    # Generate reports
    generate_delay_reports(
        project_name, contractor_name, contract_value, contract_duration,
        completion_delay, net_delay, total_penalty, daily_penalty_amount
    )

def create_delay_timeline(contract_start_date, contract_end_date, actual_start_date, actual_end_date):
    """Create timeline visualization for delays"""
    
    st.markdown("### Project Timeline Visualization")
    
    # Create timeline data
    timeline_data = []
    
    # Contract timeline
    timeline_data.append({
        'Task': 'Contract Schedule',
        'Start': contract_start_date,
        'Finish': contract_end_date,
        'Type': 'Planned'
    })
    
    # Actual timeline
    if actual_start_date:
        timeline_data.append({
            'Task': 'Actual Progress',
            'Start': actual_start_date,
            'Finish': actual_end_date,
            'Type': 'Actual'
        })
    
    df_timeline = pd.DataFrame(timeline_data)
    
    # Create Gantt chart
    fig = px.timeline(
        df_timeline,
        x_start="Start",
        x_end="Finish",
        y="Task",
        color="Type",
        color_discrete_map={'Planned': '#4CAF50', 'Actual': '#FF6B35'},
        title="Project Timeline Comparison"
    )
    
    fig.update_layout(height=300)
    st.plotly_chart(fig, use_container_width=True)

def generate_delay_reports(project_name, contractor_name, contract_value, contract_duration,
                          completion_delay, net_delay, total_penalty, daily_penalty_amount):
    """Generate downloadable delay analysis reports"""
    
    # Summary report
    summary_data = {
        'Project Details': [
            'Project Name', 'Contractor Name', 'Contract Value', 'Contract Duration',
            'Completion Delay', 'Net Penalty Delay', 'Daily Penalty Amount', 'Total Penalty Amount'
        ],
        'Values': [
            project_name, contractor_name, f"₹{contract_value:,.2f}", f"{contract_duration} days",
            f"{completion_delay} days", f"{net_delay} days", f"₹{daily_penalty_amount:,.2f}", f"₹{total_penalty:,.2f}"
        ]
    }
    
    df_summary = pd.DataFrame(summary_data)
    csv_summary = df_summary.to_csv(index=False)
    
    # Download button
    st.download_button(
        label="📥 Download Delay Analysis Report (CSV)",
        data=csv_summary,
        file_name=f"delay_analysis_{project_name}_{datetime.now().strftime('%Y%m%d')}.csv",
        mime="text/csv",
        use_container_width=True
    )
    
    # Detailed text report
    detailed_report = f"""
DELAY ANALYSIS REPORT
====================

Project Name: {project_name}
Contractor: {contractor_name}
Contract Value: ₹{contract_value:,.2f}

DELAY SUMMARY:
- Contract Duration: {contract_duration} days
- Completion Delay: {completion_delay} days
- Net Penalty Delay: {net_delay} days

PENALTY CALCULATION:
- Daily Penalty Rate: {daily_penalty_amount / contract_value * 100:.3f}% of contract value
- Daily Penalty Amount: ₹{daily_penalty_amount:,.2f}
- Total Penalty: ₹{total_penalty:,.2f}

Generated on: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
PWD Tools - Delay Calculator
"""
    
    st.download_button(
        label="📄 Download Detailed Report (TXT)",
        data=detailed_report,
        file_name=f"delay_analysis_detailed_{datetime.now().strftime('%Y%m%d')}.txt",
        mime="text/plain",
        use_container_width=True
    )

if __name__ == "__main__":
    main()
