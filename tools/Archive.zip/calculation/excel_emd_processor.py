"""
Excel EMD Processor Tool
Process EMD (Earnest Money Deposit) data from Excel files
"""

import streamlit as st
import pandas as pd
import io
from datetime import datetime, date
import sys
import os

# Add utils to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'utils'))

try:
    from excel_handler import ExcelHandler
except ImportError:
    # Fallback if utils not available
    class ExcelHandler:
        @staticmethod
        def read_excel_file(file):
            return pd.read_excel(file)

def main():
    """Main function for Excel EMD Processor tool"""
    st.markdown("### 📊 Excel EMD Processor")
    st.markdown("Process and analyze EMD (Earnest Money Deposit) data from Excel files")
    
    # Processing mode selection
    processing_mode = st.radio(
        "Select Processing Mode:",
        ["Upload Excel File", "Manual Data Entry", "Template Generator"]
    )
    
    if processing_mode == "Upload Excel File":
        process_excel_file()
    elif processing_mode == "Manual Data Entry":
        manual_data_entry()
    else:
        generate_template()

def process_excel_file():
    """Process EMD data from uploaded Excel file"""
    
    st.markdown("#### 📂 Upload Excel File for Processing")
    
    # File upload
    uploaded_file = st.file_uploader(
        "Choose Excel file",
        type=['xlsx', 'xls'],
        help="Upload Excel file containing EMD data"
    )
    
    if uploaded_file is not None:
        try:
            # Read Excel file
            df = pd.read_excel(uploaded_file)
            
            st.success("✅ File uploaded successfully!")
            
            # Display file info
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Total Rows", len(df))
            
            with col2:
                st.metric("Total Columns", len(df.columns))
            
            with col3:
                st.metric("File Size", f"{uploaded_file.size} bytes")
            
            # Show data preview
            st.markdown("### 👀 Data Preview")
            st.dataframe(df.head(10), use_container_width=True)
            
            # Column mapping
            st.markdown("### 🔗 Column Mapping")
            st.info("Map your Excel columns to EMD fields for proper processing")
            
            # Expected columns for EMD processing
            expected_columns = {
                "Tender Number": "Unique identifier for tender",
                "Contractor/Bidder Name": "Name of the bidder",
                "EMD Amount": "Earnest Money Deposit amount",
                "Deposit Date": "Date when EMD was deposited",
                "Tender Date": "Date of tender",
                "Work Description": "Description of work",
                "Contact Number": "Contact information",
                "Bank Details": "Bank account details",
                "Status": "Current status of EMD"
            }
            
            column_mapping = {}
            
            for expected_col, description in expected_columns.items():
                st.markdown(f"**{expected_col}** - {description}")
                mapped_column = st.selectbox(
                    f"Select column for {expected_col}:",
                    ["None"] + list(df.columns),
                    key=f"mapping_{expected_col}"
                )
                if mapped_column != "None":
                    column_mapping[expected_col] = mapped_column
            
            # Process data button
            if st.button("🔄 Process EMD Data", use_container_width=True):
                process_emd_data(df, column_mapping)
                
        except Exception as e:
            st.error(f"Error processing file: {str(e)}")

def process_emd_data(df, column_mapping):
    """Process the EMD data based on column mapping"""
    
    if not column_mapping:
        st.warning("Please map at least some columns before processing.")
        return
    
    # Create processed dataframe
    processed_data = []
    
    for index, row in df.iterrows():
        processed_row = {}
        
        for field, column in column_mapping.items():
            processed_row[field] = row[column] if column in df.columns else None
        
        # Add computed fields
        processed_row['Row_Number'] = index + 1
        processed_row['Processing_Date'] = datetime.now().strftime('%Y-%m-%d')
        
        # Calculate days since deposit (if deposit date available)
        if 'Deposit Date' in processed_row and processed_row['Deposit Date']:
            try:
                if isinstance(processed_row['Deposit Date'], str):
                    deposit_date = pd.to_datetime(processed_row['Deposit Date']).date()
                else:
                    deposit_date = processed_row['Deposit Date']
                
                days_since_deposit = (date.today() - deposit_date).days
                processed_row['Days_Since_Deposit'] = days_since_deposit
            except:
                processed_row['Days_Since_Deposit'] = None
        else:
            processed_row['Days_Since_Deposit'] = None
        
        processed_data.append(processed_row)
    
    # Convert to DataFrame
    processed_df = pd.DataFrame(processed_data)
    
    # Display processed data
    st.markdown("---")
    st.markdown("## 📊 PROCESSED EMD DATA")
    
    # Summary statistics
    display_emd_statistics(processed_df)
    
    # Display processed data
    st.markdown("### 📋 Processed Data Table")
    st.dataframe(processed_df, use_container_width=True)
    
    # Analysis and reporting
    generate_emd_analysis(processed_df)
    
    # Save processed data
    save_processed_data(processed_df)

def display_emd_statistics(df):
    """Display EMD statistics and summary"""
    
    st.markdown("### 📈 EMD Statistics")
    
    # Calculate statistics
    total_records = len(df)
    
    # EMD Amount statistics (if available)
    if 'EMD Amount' in df.columns:
        emd_amounts = pd.to_numeric(df['EMD Amount'], errors='coerce').dropna()
        total_emd_value = emd_amounts.sum()
        avg_emd_value = emd_amounts.mean()
        max_emd_value = emd_amounts.max()
        min_emd_value = emd_amounts.min()
    else:
        total_emd_value = avg_emd_value = max_emd_value = min_emd_value = 0
    
    # Display metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Records", total_records)
    
    with col2:
        st.metric("Total EMD Value", f"₹{total_emd_value:,.2f}" if total_emd_value else "N/A")
    
    with col3:
        st.metric("Average EMD", f"₹{avg_emd_value:,.2f}" if avg_emd_value else "N/A")
    
    with col4:
        st.metric("Max EMD", f"₹{max_emd_value:,.2f}" if max_emd_value else "N/A")
    
    # Status distribution (if available)
    if 'Status' in df.columns:
        st.markdown("### 📊 Status Distribution")
        status_counts = df['Status'].value_counts()
        
        # Create status table
        status_data = []
        for status, count in status_counts.items():
            percentage = (count / total_records) * 100
            status_data.append({
                'Status': status,
                'Count': count,
                'Percentage': f"{percentage:.1f}%"
            })
        
        status_df = pd.DataFrame(status_data)
        st.table(status_df)
    
    # Days since deposit analysis
    if 'Days_Since_Deposit' in df.columns:
        days_data = pd.to_numeric(df['Days_Since_Deposit'], errors='coerce').dropna()
        
        if not days_data.empty:
            st.markdown("### ⏰ Days Since Deposit Analysis")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Average Days", f"{days_data.mean():.0f}")
            
            with col2:
                st.metric("Max Days", f"{days_data.max():.0f}")
            
            with col3:
                pending_refunds = len(days_data[days_data > 30])
                st.metric("Pending Refunds (>30 days)", pending_refunds)

def generate_emd_analysis(df):
    """Generate detailed EMD analysis"""
    
    st.markdown("### 🔍 Detailed Analysis")
    
    analysis_type = st.selectbox(
        "Select Analysis Type:",
        ["Summary Report", "Pending Refunds", "High Value EMDs", "Contractor Analysis"]
    )
    
    if analysis_type == "Summary Report":
        generate_summary_report(df)
    elif analysis_type == "Pending Refunds":
        analyze_pending_refunds(df)
    elif analysis_type == "High Value EMDs":
        analyze_high_value_emds(df)
    else:
        analyze_by_contractor(df)

def generate_summary_report(df):
    """Generate summary report"""
    
    st.markdown("#### 📋 Summary Report")
    
    # Create summary data
    summary_info = []
    
    summary_info.append(f"Total EMD Records: {len(df)}")
    
    if 'EMD Amount' in df.columns:
        emd_amounts = pd.to_numeric(df['EMD Amount'], errors='coerce').dropna()
        summary_info.append(f"Total EMD Value: ₹{emd_amounts.sum():,.2f}")
        summary_info.append(f"Average EMD Value: ₹{emd_amounts.mean():,.2f}")
    
    if 'Days_Since_Deposit' in df.columns:
        days_data = pd.to_numeric(df['Days_Since_Deposit'], errors='coerce').dropna()
        if not days_data.empty:
            summary_info.append(f"Average Days Since Deposit: {days_data.mean():.0f}")
            summary_info.append(f"Records > 30 days: {len(days_data[days_data > 30])}")
            summary_info.append(f"Records > 90 days: {len(days_data[days_data > 90])}")
    
    if 'Status' in df.columns:
        status_counts = df['Status'].value_counts()
        summary_info.append("\nStatus Breakdown:")
        for status, count in status_counts.items():
            summary_info.append(f"  {status}: {count}")
    
    # Display summary
    for info in summary_info:
        st.write(info)

def analyze_pending_refunds(df):
    """Analyze pending refunds"""
    
    st.markdown("#### ⏰ Pending Refunds Analysis")
    
    if 'Days_Since_Deposit' not in df.columns:
        st.warning("Days since deposit data not available for analysis.")
        return
    
    # Filter pending refunds (>30 days)
    days_data = pd.to_numeric(df['Days_Since_Deposit'], errors='coerce')
    pending_mask = days_data > 30
    pending_df = df[pending_mask].copy()
    
    if pending_df.empty:
        st.info("No pending refunds found (EMDs older than 30 days).")
        return
    
    st.write(f"Found {len(pending_df)} EMDs pending for refund (>30 days)")
    
    # Priority categories
    urgent_mask = days_data > 90
    critical_mask = days_data > 180
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Normal Priority", f"{len(pending_df)} records", "30-90 days")
    
    with col2:
        urgent_count = len(df[urgent_mask])
        st.metric("Urgent Priority", f"{urgent_count} records", "90-180 days")
    
    with col3:
        critical_count = len(df[critical_mask])
        st.metric("Critical Priority", f"{critical_count} records", ">180 days")
    
    # Display pending refunds table
    if not pending_df.empty:
        display_columns = ['Tender Number', 'Contractor/Bidder Name', 'EMD Amount', 'Days_Since_Deposit']
        available_columns = [col for col in display_columns if col in pending_df.columns]
        
        if available_columns:
            st.dataframe(pending_df[available_columns], use_container_width=True)

def analyze_high_value_emds(df):
    """Analyze high value EMDs"""
    
    st.markdown("#### 💰 High Value EMDs Analysis")
    
    if 'EMD Amount' not in df.columns:
        st.warning("EMD Amount data not available for analysis.")
        return
    
    emd_amounts = pd.to_numeric(df['EMD Amount'], errors='coerce').dropna()
    
    if emd_amounts.empty:
        st.warning("No valid EMD amount data found.")
        return
    
    # Define thresholds
    threshold_high = st.number_input("High Value Threshold (₹)", min_value=0, value=100000, format="%d")
    threshold_very_high = st.number_input("Very High Value Threshold (₹)", min_value=0, value=500000, format="%d")
    
    # Filter high value EMDs
    high_value_mask = emd_amounts >= threshold_high
    very_high_value_mask = emd_amounts >= threshold_very_high
    
    high_value_df = df[df['EMD Amount'].astype(str).str.replace(',', '').str.replace('₹', '').astype(float, errors='ignore') >= threshold_high]
    very_high_value_df = df[df['EMD Amount'].astype(str).str.replace(',', '').str.replace('₹', '').astype(float, errors='ignore') >= threshold_very_high]
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.metric("High Value EMDs", f"{len(high_value_df)} records", f"≥₹{threshold_high:,}")
    
    with col2:
        st.metric("Very High Value EMDs", f"{len(very_high_value_df)} records", f"≥₹{threshold_very_high:,}")
    
    # Display high value EMDs
    if not high_value_df.empty:
        st.markdown("##### High Value EMDs Table")
        display_columns = ['Tender Number', 'Contractor/Bidder Name', 'EMD Amount', 'Work Description']
        available_columns = [col for col in display_columns if col in high_value_df.columns]
        
        if available_columns:
            st.dataframe(high_value_df[available_columns], use_container_width=True)

def analyze_by_contractor(df):
    """Analyze EMDs by contractor"""
    
    st.markdown("#### 👥 Contractor Analysis")
    
    if 'Contractor/Bidder Name' not in df.columns:
        st.warning("Contractor/Bidder Name data not available for analysis.")
        return
    
    # Group by contractor
    contractor_groups = df.groupby('Contractor/Bidder Name')
    
    # Create contractor summary
    contractor_summary = []
    
    for contractor, group in contractor_groups:
        summary = {
            'Contractor': contractor,
            'Total EMDs': len(group),
        }
        
        if 'EMD Amount' in df.columns:
            emd_amounts = pd.to_numeric(group['EMD Amount'], errors='coerce').dropna()
            summary['Total EMD Value'] = f"₹{emd_amounts.sum():,.2f}" if not emd_amounts.empty else "N/A"
            summary['Average EMD'] = f"₹{emd_amounts.mean():,.2f}" if not emd_amounts.empty else "N/A"
        
        if 'Days_Since_Deposit' in df.columns:
            days_data = pd.to_numeric(group['Days_Since_Deposit'], errors='coerce').dropna()
            summary['Pending Refunds'] = len(days_data[days_data > 30]) if not days_data.empty else 0
        
        contractor_summary.append(summary)
    
    # Convert to DataFrame and display
    contractor_df = pd.DataFrame(contractor_summary)
    
    if not contractor_df.empty:
        # Sort by total EMD value or count
        if 'Total EMD Value' in contractor_df.columns:
            # Convert EMD values to numeric for sorting
            contractor_df['Sort_Value'] = contractor_df['Total EMD Value'].str.replace('₹', '').str.replace(',', '').str.replace('N/A', '0').astype(float)
            contractor_df = contractor_df.sort_values('Sort_Value', ascending=False).drop('Sort_Value', axis=1)
        
        st.dataframe(contractor_df, use_container_width=True)
        
        # Top contractors
        st.markdown("##### 🏆 Top Contractors by EMD Count")
        top_contractors = contractor_df.head(5)
        st.table(top_contractors[['Contractor', 'Total EMDs']])

def manual_data_entry():
    """Manual EMD data entry interface"""
    
    st.markdown("#### ✏️ Manual EMD Data Entry")
    
    # Initialize session state for manual entries
    if 'manual_emd_entries' not in st.session_state:
        st.session_state.manual_emd_entries = []
    
    # Entry form
    with st.form("manual_emd_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            tender_number = st.text_input("Tender Number*", placeholder="Enter tender number")
            contractor_name = st.text_input("Contractor/Bidder Name*", placeholder="Enter contractor name")
            emd_amount = st.number_input("EMD Amount (₹)*", min_value=0.0, format="%.2f")
            deposit_date = st.date_input("Deposit Date*", value=date.today())
        
        with col2:
            tender_date = st.date_input("Tender Date", value=date.today())
            work_description = st.text_area("Work Description", height=80)
            contact_number = st.text_input("Contact Number", placeholder="Phone/Mobile number")
            bank_details = st.text_input("Bank Details", placeholder="Bank account details")
        
        status = st.selectbox("Status", [
            "Active", "Pending Refund", "Refunded", "Forfeited", "Under Review"
        ])
        
        remarks = st.text_area("Remarks", height=60, placeholder="Additional notes...")
        
        submitted = st.form_submit_button("Add EMD Entry", use_container_width=True)
    
    if submitted:
        if not all([tender_number, contractor_name, emd_amount > 0]):
            st.error("Please fill all required fields marked with *")
            return
        
        # Add entry
        new_entry = {
            'Tender Number': tender_number,
            'Contractor/Bidder Name': contractor_name,
            'EMD Amount': emd_amount,
            'Deposit Date': deposit_date,
            'Tender Date': tender_date,
            'Work Description': work_description,
            'Contact Number': contact_number,
            'Bank Details': bank_details,
            'Status': status,
            'Remarks': remarks,
            'Days_Since_Deposit': (date.today() - deposit_date).days,
            'Entry_Date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        st.session_state.manual_emd_entries.append(new_entry)
        st.success("✅ EMD entry added successfully!")
        st.rerun()
    
    # Display manual entries
    if st.session_state.manual_emd_entries:
        st.markdown("### 📋 Manual EMD Entries")
        
        entries_df = pd.DataFrame(st.session_state.manual_emd_entries)
        st.dataframe(entries_df, use_container_width=True)
        
        # Process manual entries
        if st.button("🔄 Process Manual Entries"):
            process_emd_data(entries_df, {
                'Tender Number': 'Tender Number',
                'Contractor/Bidder Name': 'Contractor/Bidder Name',
                'EMD Amount': 'EMD Amount',
                'Deposit Date': 'Deposit Date',
                'Status': 'Status'
            })
        
        # Clear entries
        if st.button("🗑️ Clear All Entries"):
            st.session_state.manual_emd_entries = []
            st.rerun()

def generate_template():
    """Generate Excel template for EMD data"""
    
    st.markdown("#### 📝 Generate Excel Template")
    
    st.info("Download a pre-formatted Excel template for EMD data entry")
    
    # Template columns
    template_columns = [
        'Tender Number',
        'Contractor/Bidder Name', 
        'EMD Amount',
        'Deposit Date',
        'Tender Date',
        'Work Description',
        'Contact Number',
        'Bank Details',
        'Status',
        'Remarks'
    ]
    
    # Sample data for template
    sample_data = {
        'Tender Number': ['T001/2024', 'T002/2024', 'T003/2024'],
        'Contractor/Bidder Name': ['ABC Construction', 'XYZ Builders', 'PQR Contractors'],
        'EMD Amount': [50000, 75000, 100000],
        'Deposit Date': ['2024-01-15', '2024-01-20', '2024-01-25'],
        'Tender Date': ['2024-01-10', '2024-01-15', '2024-01-20'],
        'Work Description': ['Road Construction', 'Building Construction', 'Bridge Construction'],
        'Contact Number': ['9876543210', '9876543211', '9876543212'],
        'Bank Details': ['SBI Account', 'HDFC Account', 'ICICI Account'],
        'Status': ['Active', 'Pending Refund', 'Active'],
        'Remarks': ['Initial deposit', 'Awaiting refund approval', 'Under process']
    }
    
    # Create template DataFrame
    template_df = pd.DataFrame(sample_data)
    
    # Display template preview
    st.markdown("### 👀 Template Preview")
    st.dataframe(template_df, use_container_width=True)
    
    # Generate downloadable template
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        # Empty template
        empty_template = pd.DataFrame(columns=template_columns)
        empty_template.to_excel(writer, sheet_name='EMD_Template', index=False)
        
        # Sample data
        template_df.to_excel(writer, sheet_name='Sample_Data', index=False)
        
        # Instructions
        instructions = pd.DataFrame({
            'Instructions': [
                'EMD Data Processing Template',
                '',
                'Sheet Descriptions:',
                '1. EMD_Template: Use this sheet for entering your EMD data',
                '2. Sample_Data: Example data showing the expected format',
                '',
                'Column Descriptions:',
                'Tender Number: Unique identifier for each tender',
                'Contractor/Bidder Name: Name of the bidding organization',
                'EMD Amount: Earnest Money Deposit amount in rupees',
                'Deposit Date: Date when EMD was deposited (YYYY-MM-DD format)',
                'Tender Date: Date of tender publication',
                'Work Description: Brief description of the work',
                'Contact Number: Phone/mobile number of contractor',
                'Bank Details: Bank account information',
                'Status: Current status (Active/Pending Refund/Refunded/Forfeited)',
                'Remarks: Additional notes or comments',
                '',
                'Important Notes:',
                '- Required fields: Tender Number, Contractor Name, EMD Amount, Deposit Date',
                '- Use date format: YYYY-MM-DD (e.g., 2024-01-15)',
                '- EMD Amount should be numeric value without currency symbols',
                '- Status should be one of: Active, Pending Refund, Refunded, Forfeited, Under Review',
                '',
                f'Template generated on: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}',
                'PWD Tools - Excel EMD Processor'
            ]
        })
        instructions.to_excel(writer, sheet_name='Instructions', index=False)
    
    output.seek(0)
    
    # Download button
    st.download_button(
        label="📥 Download EMD Template (Excel)",
        data=output.getvalue(),
        file_name=f"EMD_Template_{datetime.now().strftime('%Y%m%d')}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=True
    )

def save_processed_data(df):
    """Save processed EMD data"""
    
    st.markdown("### 💾 Save Processed Data")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Save as CSV
        csv_data = df.to_csv(index=False)
        st.download_button(
            label="📥 Download as CSV",
            data=csv_data,
            file_name=f"processed_emd_data_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv",
            use_container_width=True
        )
    
    with col2:
        # Save as Excel
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Processed_EMD_Data', index=False)
            
            # Add summary sheet
            summary_data = {
                'Metric': ['Total Records', 'Processing Date', 'Tool Version'],
                'Value': [len(df), datetime.now().strftime('%Y-%m-%d %H:%M:%S'), '2.0.0']
            }
            summary_df = pd.DataFrame(summary_data)
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
        
        output.seek(0)
        
        st.download_button(
            label="📥 Download as Excel",
            data=output.getvalue(),
            file_name=f"processed_emd_data_{datetime.now().strftime('%Y%m%d')}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True
        )

if __name__ == "__main__":
    main()
