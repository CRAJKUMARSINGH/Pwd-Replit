"""
Deductions Table Tool
Manage and calculate various deductions for PWD contracts
"""

import streamlit as st
import pandas as pd
from datetime import datetime, date
import io

def main():
    """Main function for Deductions Table tool"""
    st.markdown("### 📊 Deductions Table Manager")
    st.markdown("Manage and calculate various deductions for PWD contracts and payments")
    
    # Deduction type selection
    deduction_mode = st.radio(
        "Select Mode:",
        ["Create New Deductions Table", "Load Existing Template", "Quick Calculator"]
    )
    
    if deduction_mode == "Create New Deductions Table":
        create_deductions_table()
    elif deduction_mode == "Load Existing Template":
        load_template()
    else:
        quick_calculator()

def create_deductions_table():
    """Create a new deductions table"""
    
    st.markdown("#### 📋 Create New Deductions Table")
    
    # Project information
    with st.form("project_info_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            project_name = st.text_input("Project Name*", placeholder="Enter project name")
            contractor_name = st.text_input("Contractor Name*", placeholder="Enter contractor name")
            contract_value = st.number_input("Contract Value (₹)*", min_value=0.0, format="%.2f")
        
        with col2:
            contract_no = st.text_input("Contract Number", placeholder="Contract ID")
            bill_amount = st.number_input("Current Bill Amount (₹)*", min_value=0.0, format="%.2f")
            bill_date = st.date_input("Bill Date*", value=date.today())
        
        submitted = st.form_submit_button("Setup Deductions Table")
    
    if submitted and all([project_name, contractor_name, contract_value > 0, bill_amount > 0]):
        st.session_state.project_info = {
            'name': project_name,
            'contractor': contractor_name,
            'contract_value': contract_value,
            'contract_no': contract_no,
            'bill_amount': bill_amount,
            'bill_date': bill_date
        }
        st.success("✅ Project information saved. Now configure deductions below.")
        
        # Show deductions configuration
        configure_deductions()

def configure_deductions():
    """Configure various deductions"""
    
    if 'project_info' not in st.session_state:
        st.warning("Please setup project information first.")
        return
    
    project = st.session_state.project_info
    
    st.markdown("---")
    st.markdown("### 🔧 Configure Deductions")
    
    # Initialize deductions in session state
    if 'deductions' not in st.session_state:
        st.session_state.deductions = []
    
    # Deduction categories with predefined rates
    deduction_categories = {
        "Income Tax (TDS)": {"default_rate": 1.0, "description": "Tax Deducted at Source"},
        "Labour Cess": {"default_rate": 1.0, "description": "Building & Construction Workers Welfare Cess"},
        "GST (TDS)": {"default_rate": 2.0, "description": "Goods and Services Tax TDS"},
        "Security Deposit": {"default_rate": 5.0, "description": "Security deposit as per contract"},
        "Professional Tax": {"default_rate": 0.1, "description": "Professional tax deduction"},
        "Performance Guarantee": {"default_rate": 3.0, "description": "Performance guarantee amount"},
        "Advance Recovery": {"default_rate": 0.0, "description": "Recovery of advance payments"},
        "Material Advance": {"default_rate": 0.0, "description": "Material advance recovery"},
        "Equipment Advance": {"default_rate": 0.0, "description": "Equipment advance recovery"},
        "Penalty": {"default_rate": 0.0, "description": "Penalty for delays or defects"},
        "Insurance Premium": {"default_rate": 0.5, "description": "Insurance premium deduction"},
        "Other Deductions": {"default_rate": 0.0, "description": "Any other deductions"}
    }
    
    # Add new deduction
    with st.expander("➕ Add New Deduction", expanded=True):
        with st.form("add_deduction_form"):
            col1, col2, col3 = st.columns(3)
            
            with col1:
                deduction_type = st.selectbox("Deduction Type", list(deduction_categories.keys()))
                custom_type = st.text_input("Custom Type (if Other)", placeholder="Enter custom deduction type")
            
            with col2:
                calculation_method = st.selectbox("Calculation Method", [
                    "Percentage of Bill Amount",
                    "Fixed Amount",
                    "Percentage of Contract Value"
                ])
                
                if calculation_method == "Percentage of Bill Amount":
                    rate = st.number_input("Rate (%)", min_value=0.0, max_value=100.0, 
                                         value=deduction_categories[deduction_type]["default_rate"], format="%.2f")
                    amount = (project['bill_amount'] * rate) / 100
                elif calculation_method == "Fixed Amount":
                    amount = st.number_input("Fixed Amount (₹)", min_value=0.0, format="%.2f")
                    rate = 0.0
                else:
                    rate = st.number_input("Rate (%)", min_value=0.0, max_value=100.0, 
                                         value=deduction_categories[deduction_type]["default_rate"], format="%.2f")
                    amount = (project['contract_value'] * rate) / 100
            
            with col3:
                is_statutory = st.checkbox("Statutory Deduction")
                remarks = st.text_area("Remarks", height=60, placeholder="Additional notes...")
            
            add_deduction = st.form_submit_button("Add Deduction")
        
        if add_deduction:
            final_type = custom_type if deduction_type == "Other Deductions" and custom_type else deduction_type
            
            new_deduction = {
                'type': final_type,
                'method': calculation_method,
                'rate': rate,
                'amount': amount,
                'statutory': is_statutory,
                'remarks': remarks,
                'description': deduction_categories.get(deduction_type, {}).get('description', '')
            }
            
            st.session_state.deductions.append(new_deduction)
            st.success(f"✅ {final_type} added successfully!")
            st.rerun()
    
    # Display current deductions
    if st.session_state.deductions:
        display_deductions_table(project)

def display_deductions_table(project):
    """Display the deductions table"""
    
    st.markdown("### 📋 Current Deductions Table")
    
    # Calculate totals
    total_deductions = sum([d['amount'] for d in st.session_state.deductions])
    net_amount = project['bill_amount'] - total_deductions
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Bill Amount", f"₹{project['bill_amount']:,.2f}")
    
    with col2:
        st.metric("Total Deductions", f"₹{total_deductions:,.2f}")
    
    with col3:
        st.metric("Net Payable", f"₹{net_amount:,.2f}")
    
    with col4:
        deduction_percent = (total_deductions / project['bill_amount']) * 100
        st.metric("Deduction %", f"{deduction_percent:.2f}%")
    
    # Deductions table
    deductions_data = []
    for i, deduction in enumerate(st.session_state.deductions):
        deductions_data.append({
            'S.No.': i + 1,
            'Deduction Type': deduction['type'],
            'Calculation Method': deduction['method'],
            'Rate (%)': f"{deduction['rate']:.2f}" if deduction['rate'] > 0 else "N/A",
            'Amount (₹)': f"{deduction['amount']:,.2f}",
            'Statutory': "Yes" if deduction['statutory'] else "No",
            'Remarks': deduction['remarks'][:30] + "..." if len(deduction['remarks']) > 30 else deduction['remarks']
        })
    
    df_deductions = pd.DataFrame(deductions_data)
    
    # Display table with edit/delete options
    st.dataframe(df_deductions, use_container_width=True)
    
    # Edit/Delete options
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        if st.button("🗑️ Clear All Deductions"):
            st.session_state.deductions = []
            st.rerun()
    
    with col2:
        if st.button("📊 Generate Summary"):
            generate_deductions_summary(project, total_deductions, net_amount)
    
    with col3:
        if st.button("📥 Download Table"):
            generate_downloadable_table(project, df_deductions, total_deductions, net_amount)

def load_template():
    """Load existing deductions template"""
    
    st.markdown("#### 📂 Load Existing Template")
    
    # Predefined templates
    templates = {
        "Standard Construction Contract": {
            "Income Tax (TDS)": 1.0,
            "Labour Cess": 1.0,
            "GST (TDS)": 2.0,
            "Security Deposit": 5.0,
            "Performance Guarantee": 3.0
        },
        "Supply Contract": {
            "Income Tax (TDS)": 1.0,
            "GST (TDS)": 2.0,
            "Security Deposit": 2.5,
            "Performance Guarantee": 3.0
        },
        "Service Contract": {
            "Income Tax (TDS)": 10.0,
            "Professional Tax": 0.1,
            "GST (TDS)": 2.0,
            "Security Deposit": 3.0
        },
        "Maintenance Contract": {
            "Income Tax (TDS)": 2.0,
            "Labour Cess": 1.0,
            "Security Deposit": 5.0,
            "Insurance Premium": 0.5
        }
    }
    
    selected_template = st.selectbox("Select Template:", list(templates.keys()))
    
    if st.button("Load Template"):
        # Clear existing deductions
        st.session_state.deductions = []
        
        # Load template deductions
        template_deductions = templates[selected_template]
        
        for deduction_type, rate in template_deductions.items():
            new_deduction = {
                'type': deduction_type,
                'method': "Percentage of Bill Amount",
                'rate': rate,
                'amount': 0.0,  # Will be calculated when bill amount is entered
                'statutory': deduction_type in ["Income Tax (TDS)", "Labour Cess", "GST (TDS)", "Professional Tax"],
                'remarks': f"From {selected_template} template",
                'description': f"Standard {deduction_type.lower()} deduction"
            }
            st.session_state.deductions.append(new_deduction)
        
        st.success(f"✅ {selected_template} template loaded successfully!")
        st.info("Please enter project information to calculate deduction amounts.")

def quick_calculator():
    """Quick deduction calculator"""
    
    st.markdown("#### ⚡ Quick Deductions Calculator")
    
    with st.form("quick_calc_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            bill_amount = st.number_input("Bill Amount (₹)*", min_value=0.0, format="%.2f")
            
            # Common deductions
            st.markdown("**Common Deductions:**")
            income_tax = st.number_input("Income Tax Rate (%)", min_value=0.0, max_value=20.0, value=1.0, format="%.2f")
            labour_cess = st.number_input("Labour Cess Rate (%)", min_value=0.0, max_value=5.0, value=1.0, format="%.2f")
            gst_tds = st.number_input("GST TDS Rate (%)", min_value=0.0, max_value=10.0, value=2.0, format="%.2f")
        
        with col2:
            security_deposit = st.number_input("Security Deposit Rate (%)", min_value=0.0, max_value=20.0, value=5.0, format="%.2f")
            performance_guarantee = st.number_input("Performance Guarantee Rate (%)", min_value=0.0, max_value=10.0, value=3.0, format="%.2f")
            
            # Additional deductions
            st.markdown("**Additional Deductions:**")
            advance_recovery = st.number_input("Advance Recovery (₹)", min_value=0.0, format="%.2f")
            penalty = st.number_input("Penalty (₹)", min_value=0.0, format="%.2f")
            other_deductions = st.number_input("Other Deductions (₹)", min_value=0.0, format="%.2f")
        
        calculate = st.form_submit_button("Calculate Deductions", use_container_width=True)
    
    if calculate and bill_amount > 0:
        # Calculate amounts
        income_tax_amount = (bill_amount * income_tax) / 100
        labour_cess_amount = (bill_amount * labour_cess) / 100
        gst_tds_amount = (bill_amount * gst_tds) / 100
        security_deposit_amount = (bill_amount * security_deposit) / 100
        performance_guarantee_amount = (bill_amount * performance_guarantee) / 100
        
        total_percentage_deductions = (
            income_tax_amount + labour_cess_amount + gst_tds_amount + 
            security_deposit_amount + performance_guarantee_amount
        )
        
        total_fixed_deductions = advance_recovery + penalty + other_deductions
        total_deductions = total_percentage_deductions + total_fixed_deductions
        net_amount = bill_amount - total_deductions
        
        # Display results
        st.success("✅ Quick calculation completed!")
        
        # Summary
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Bill Amount", f"₹{bill_amount:,.2f}")
        
        with col2:
            st.metric("Total Deductions", f"₹{total_deductions:,.2f}")
        
        with col3:
            st.metric("Net Payable", f"₹{net_amount:,.2f}")
        
        # Detailed breakdown
        st.markdown("### Deductions Breakdown")
        
        breakdown_data = []
        
        if income_tax_amount > 0:
            breakdown_data.append({"Deduction": "Income Tax (TDS)", "Rate": f"{income_tax}%", "Amount": f"₹{income_tax_amount:,.2f}"})
        if labour_cess_amount > 0:
            breakdown_data.append({"Deduction": "Labour Cess", "Rate": f"{labour_cess}%", "Amount": f"₹{labour_cess_amount:,.2f}"})
        if gst_tds_amount > 0:
            breakdown_data.append({"Deduction": "GST TDS", "Rate": f"{gst_tds}%", "Amount": f"₹{gst_tds_amount:,.2f}"})
        if security_deposit_amount > 0:
            breakdown_data.append({"Deduction": "Security Deposit", "Rate": f"{security_deposit}%", "Amount": f"₹{security_deposit_amount:,.2f}"})
        if performance_guarantee_amount > 0:
            breakdown_data.append({"Deduction": "Performance Guarantee", "Rate": f"{performance_guarantee}%", "Amount": f"₹{performance_guarantee_amount:,.2f}"})
        if advance_recovery > 0:
            breakdown_data.append({"Deduction": "Advance Recovery", "Rate": "Fixed", "Amount": f"₹{advance_recovery:,.2f}"})
        if penalty > 0:
            breakdown_data.append({"Deduction": "Penalty", "Rate": "Fixed", "Amount": f"₹{penalty:,.2f}"})
        if other_deductions > 0:
            breakdown_data.append({"Deduction": "Other Deductions", "Rate": "Fixed", "Amount": f"₹{other_deductions:,.2f}"})
        
        if breakdown_data:
            df_breakdown = pd.DataFrame(breakdown_data)
            st.table(df_breakdown)
        
        # Download quick calculation
        quick_calc_data = {
            'Item': ['Bill Amount'] + [item['Deduction'] for item in breakdown_data] + ['Total Deductions', 'Net Payable Amount'],
            'Amount': [f"₹{bill_amount:,.2f}"] + [item['Amount'] for item in breakdown_data] + [f"₹{total_deductions:,.2f}", f"₹{net_amount:,.2f}"]
        }
        
        df_quick = pd.DataFrame(quick_calc_data)
        csv_quick = df_quick.to_csv(index=False)
        
        st.download_button(
            label="📥 Download Quick Calculation (CSV)",
            data=csv_quick,
            file_name=f"quick_deductions_calc_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv",
            use_container_width=True
        )

def generate_deductions_summary(project, total_deductions, net_amount):
    """Generate deductions summary"""
    
    st.markdown("---")
    st.markdown("## 📊 DEDUCTIONS SUMMARY REPORT")
    
    # Project header
    st.markdown(f"""
    **Project:** {project['name']}  
    **Contractor:** {project['contractor']}  
    **Contract No.:** {project['contract_no']}  
    **Bill Date:** {project['bill_date'].strftime('%d/%m/%Y')}
    """)
    
    # Summary table
    summary_data = {
        'Description': ['Contract Value', 'Current Bill Amount', 'Total Deductions', 'Net Payable Amount'],
        'Amount (₹)': [
            f"{project['contract_value']:,.2f}",
            f"{project['bill_amount']:,.2f}", 
            f"{total_deductions:,.2f}",
            f"{net_amount:,.2f}"
        ]
    }
    
    df_summary = pd.DataFrame(summary_data)
    st.table(df_summary)
    
    # Statutory vs Non-statutory breakdown
    statutory_deductions = sum([d['amount'] for d in st.session_state.deductions if d['statutory']])
    non_statutory_deductions = total_deductions - statutory_deductions
    
    st.markdown("### Deduction Categories")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.metric("Statutory Deductions", f"₹{statutory_deductions:,.2f}")
    
    with col2:
        st.metric("Non-Statutory Deductions", f"₹{non_statutory_deductions:,.2f}")

def generate_downloadable_table(project, df_deductions, total_deductions, net_amount):
    """Generate downloadable deductions table"""
    
    # Enhanced data for download
    download_data = {
        'Project Information': [
            f"Project Name: {project['name']}",
            f"Contractor: {project['contractor']}",
            f"Contract No.: {project['contract_no']}",
            f"Contract Value: ₹{project['contract_value']:,.2f}",
            f"Bill Amount: ₹{project['bill_amount']:,.2f}",
            f"Bill Date: {project['bill_date'].strftime('%d/%m/%Y')}",
            "",
            "DEDUCTIONS BREAKDOWN:",
            ""
        ]
    }
    
    # Add deduction details
    for i, deduction in enumerate(st.session_state.deductions):
        download_data['Project Information'].extend([
            f"{i+1}. {deduction['type']}",
            f"   Method: {deduction['method']}",
            f"   Rate: {deduction['rate']:.2f}%" if deduction['rate'] > 0 else "   Amount: Fixed",
            f"   Amount: ₹{deduction['amount']:,.2f}",
            f"   Statutory: {'Yes' if deduction['statutory'] else 'No'}",
            f"   Remarks: {deduction['remarks']}",
            ""
        ])
    
    # Add summary
    download_data['Project Information'].extend([
        "SUMMARY:",
        f"Total Deductions: ₹{total_deductions:,.2f}",
        f"Net Payable Amount: ₹{net_amount:,.2f}",
        f"Generated on: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}",
        "PWD Tools - Deductions Table Manager"
    ])
    
    df_download = pd.DataFrame(download_data)
    csv_download = df_download.to_csv(index=False)
    
    st.download_button(
        label="📥 Download Complete Deductions Report (CSV)",
        data=csv_download,
        file_name=f"deductions_table_{project['name'].replace(' ', '_')}_{datetime.now().strftime('%Y%m%d')}.csv",
        mime="text/csv",
        use_container_width=True
    )

if __name__ == "__main__":
    main()
